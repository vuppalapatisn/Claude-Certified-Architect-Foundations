#!/usr/bin/env bash
# PostToolUse hook: format Java after Claude edits it.
# Registered in .claude/settings.json under hooks.PostToolUse.
set -euo pipefail

payload=$(cat)
file=$(printf '%s' "$payload" | python3 -c \
  'import json,sys; print(json.load(sys.stdin).get("tool_input",{}).get("file_path",""))' 2>/dev/null || true)

case "$file" in
  *.java) ;;
  *) exit 0 ;;
esac

if [ -x ./mvnw ]; then
  ./mvnw -q spotless:apply -DspotlessFiles="$file" >/dev/null 2>&1 || true
fi
exit 0
