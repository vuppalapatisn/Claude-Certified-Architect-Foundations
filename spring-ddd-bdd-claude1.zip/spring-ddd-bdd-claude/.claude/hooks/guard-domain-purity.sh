#!/usr/bin/env bash
# PreToolUse hook: block framework imports from entering the domain layer.
#
# CLAUDE.md is guidance, not enforcement — Claude may still write an @Entity
# into an aggregate. This hook refuses the edit regardless of what Claude
# decides. Exit code 2 blocks the tool call and returns stderr to Claude.
set -euo pipefail

payload=$(cat)
read -r file content < <(printf '%s' "$payload" | python3 -c '
import json,sys
d = json.load(sys.stdin).get("tool_input", {})
body = d.get("content") or d.get("new_string") or ""
print(d.get("file_path",""), json.dumps(body))
' 2>/dev/null || echo " \"\"")

case "$file" in
  */domain/*) ;;
  *) exit 0 ;;
esac

banned='jakarta\.persistence|javax\.persistence|org\.springframework|com\.fasterxml\.jackson|lombok'
if printf '%s' "$content" | python3 -c 'import json,sys; sys.stdout.write(json.loads(sys.stdin.read()))' 2>/dev/null \
   | grep -Eq "^import ($banned)"; then
  echo "BLOCKED: $file is in the domain layer and must not import a framework." >&2
  echo "Map persistence in infrastructure/persistence instead. See .claude/rules/domain-layer.md" >&2
  exit 2
fi
exit 0
