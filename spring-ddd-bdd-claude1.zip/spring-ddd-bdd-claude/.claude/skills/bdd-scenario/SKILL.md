---
name: bdd-scenario
description: Use when writing, reviewing, or refactoring Gherkin feature files and Cucumber step definitions in this project — including turning a plain-language requirement into scenarios, finding missing edge cases, and removing technical detail that has leaked into the Gherkin.
---

# Writing scenarios in this codebase

## Interrogate before writing

A requirement as handed over is always incomplete. Before writing a scenario,
find and ask about:

- Boundaries, and the behaviour exactly at the boundary
- The empty case, the single case, the maximum case
- Every rejection path and what the customer sees for each
- Repeat invocation — is the operation idempotent?
- Which glossary terms are missing, and which existing rule this contradicts

## Declarative, not imperative

| Avoid | Prefer |
| --- | --- |
| `When I POST /api/v1/orders with {...}` | `When the customer places an order for 2 units of "SKU-100"` |
| `Then the response status is 409` | `Then the order is rejected because it is already shipped` |
| `Given a row exists in the orders table` | `Given a placed order for "SKU-100"` |
| `When I click Submit` | `When the customer confirms the basket` |

The test is whether a domain expert who has never seen the codebase can read the
scenario and say whether it describes correct behaviour.

## Structure

```gherkin
@FR-012
Feature: Order cancellation
  So that customers are not charged for goods they no longer want,
  an order may be cancelled at any point before it ships.

  Background:
    Given a customer "Ada" with a placed order for 3 units of "SKU-100"

  Scenario: Cancelling a placed order
    When Ada cancels the order because she changed her mind
    Then the order is cancelled
    And no charge is taken

  Scenario: Cancelling an order that has already shipped
    Given the order has shipped
    When Ada cancels the order because she changed her mind
    Then the cancellation is rejected because the order has shipped
    And the order remains shipped

  Scenario Outline: Cancellation window by fulfilment state
    Given the order is <state>
    When Ada cancels the order because she changed her mind
    Then the cancellation is <outcome>

    Examples:
      | state     | outcome  |
      | placed    | accepted |
      | picked    | accepted |
      | packed    | accepted |
      | shipped   | rejected |
      | delivered | rejected |
```

## Step definitions stay thin

Glue translates one sentence into one call and asserts on the result. State is
shared through a scenario-scoped context object, never a static field. If a step
needs a business rule to do its job, that rule belongs in the domain.

## Checklist

- [ ] Tagged with its requirement ID
- [ ] One `When` per scenario
- [ ] No HTTP, JSON, SQL, or table names in the Gherkin
- [ ] Every rejection path has its own scenario
- [ ] Scenario passes alone: `./mvnw verify -Pbdd -Dcucumber.filter.tags="@FR-012"`
- [ ] No undefined or ambiguous steps reported
