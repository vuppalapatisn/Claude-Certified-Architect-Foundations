---
name: ddd-aggregate
description: Use when creating or refactoring a DDD aggregate, entity, or value object in this Spring Boot codebase — including deciding aggregate boundaries, enforcing invariants, raising domain events, and keeping the domain free of framework dependencies. Also use when an aggregate looks anaemic or when persistence concerns have leaked into the domain.
---

# Building aggregates in this codebase

## Decide the boundary first

Ask: which rules must be true the instant a transaction commits? Those rules,
and only those, define the aggregate. Everything else is another aggregate,
reached by ID and kept consistent through events.

Default to the smallest boundary that holds an invariant. A large aggregate is
a contention point and a lost-update risk. If you find yourself loading a
collection only to count it, the collection probably belongs elsewhere.

## The shape

See @reference-aggregate.md for a complete annotated example.

Rules, in order of how often they are broken here:

1. No public setters. Mutation happens through a named behaviour.
2. Validate before mutating, so the aggregate is never observably invalid.
3. Record a domain event on every successful state change.
4. Expose collections as `List.copyOf(...)`, never the live list.
5. Reference other aggregates by typed ID.
6. No Spring, JPA, Jackson, or Lombok annotations anywhere in `domain`.
7. Take time as an input (`Clock` or a passed timestamp). Never call `now()`.

## Value objects

Records with a compact constructor that validates. If a concept has no identity
and two instances with the same attributes are interchangeable, it is a value
object — prefer it over an entity. Money, quantity, address, email, and every ID
are value objects.

## Checklist before you finish

- [ ] Every invariant has a unit test, including the rejection case
- [ ] The aggregate compiles with no imports outside `java.*` and its own context
- [ ] Every behaviour name appears in the glossary
- [ ] `ArchitectureTest` passes
- [ ] `docs/ddd/aggregates.md` records the boundary and its invariants
