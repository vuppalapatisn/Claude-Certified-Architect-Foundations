# Annotated reference aggregate

```java
public final class Order {

    private final OrderId id;
    private final CustomerId customerId;
    private final List<OrderLine> lines;
    private OrderStatus status;
    private final List<DomainEvent> events = new ArrayList<>();

    private Order(OrderId id, CustomerId customerId, List<OrderLine> lines, OrderStatus status) {
        this.id = id;
        this.customerId = customerId;
        this.lines = new ArrayList<>(lines);
        this.status = status;
    }

    // Static factory: the only way to create a valid new Order.
    public static Order place(OrderId id, CustomerId customerId, List<OrderLine> lines) {
        if (lines.isEmpty()) {
            throw new DomainRuleViolation("An order must contain at least one line");
        }
        Order order = new Order(id, customerId, lines, OrderStatus.PLACED);
        order.events.add(new OrderPlaced(id, customerId, order.total()));
        return order;
    }

    // Reconstitution from persistence — no events, no validation of history.
    public static Order rehydrate(OrderId id, CustomerId customerId,
                                  List<OrderLine> lines, OrderStatus status) {
        return new Order(id, customerId, lines, status);
    }

    // Behaviour: validate, mutate, record.
    public void cancel(CancellationReason reason, Instant occurredAt) {
        if (status == OrderStatus.SHIPPED) {
            throw new DomainRuleViolation("A shipped order cannot be cancelled");
        }
        if (status == OrderStatus.CANCELLED) {
            return;                       // idempotent, not an error
        }
        this.status = OrderStatus.CANCELLED;
        this.events.add(new OrderCancelled(id, reason, occurredAt));
    }

    public Money total() {
        return lines.stream().map(OrderLine::subtotal)
                   .reduce(Money.zero(Currency.EUR), Money::plus);
    }

    public List<OrderLine> lines() {
        return List.copyOf(lines);        // defensive copy
    }

    public List<DomainEvent> pullEvents() {
        List<DomainEvent> pulled = List.copyOf(events);
        events.clear();
        return pulled;
    }
}
```

## Why each piece

- `place` returns a valid object or throws. There is no window in which an
  `Order` exists without lines.
- `rehydrate` exists for the persistence adapter only. It skips event recording,
  because loading is not a business fact.
- `cancel` is idempotent on repeat, rejects the genuinely invalid transition,
  and takes the timestamp rather than reading the clock.
- `pullEvents` is drained by the application service after a successful save,
  so events are published only for committed facts.
