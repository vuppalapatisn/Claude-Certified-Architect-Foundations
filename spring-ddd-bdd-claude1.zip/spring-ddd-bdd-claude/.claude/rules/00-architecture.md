# Architecture rules (always loaded)

No `paths` frontmatter, so this applies to every file in the project.

## Layer dependency direction

```
api ──┐
       ├──> application ──> domain <── infrastructure
       │                      ^
       └──────────────────────┘  (never the reverse)
```

- `domain` has no outbound dependencies on other layers, Spring, JPA, or Jackson.
- `application` depends on `domain` and on ports declared in `domain/port`.
- `infrastructure` and `api` implement ports and depend inward.
- Nothing depends on `api`.

## Where things go

| Thing | Package |
| --- | --- |
| Aggregate root, entity, value object | `ordering/domain/model` |
| Domain event | `ordering/domain/event` |
| Repository / gateway interface (port) | `ordering/domain/port` |
| Use case interface + command/result | `ordering/application/command` |
| Use case implementation | `ordering/application/service` |
| JPA entity, Spring Data repo, adapter | `ordering/infrastructure/persistence` |
| REST controller, request/response DTO | `ordering/api`, `ordering/api/dto` |

## Adding a bounded context

Do not do this without asking. A new context means a new top-level package,
its own `domain`/`application`/`infrastructure`/`api`, an entry in
`docs/ddd/context-map.md`, and an ADR explaining the integration pattern.
