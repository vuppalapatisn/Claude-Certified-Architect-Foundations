---
paths:
  - "src/main/java/**/api/**/*.java"
---

# REST API rules

- Controllers are thin: deserialize, delegate to one use case, map the result
  to a response DTO, set the status code. No business logic, no `@Transactional`.
- Request/response DTOs are records in `api/dto`, validated with Bean Validation
  (`@NotNull`, `@Positive`). Never expose an aggregate or JPA entity as JSON.
- URLs are plural nouns: `/api/v1/orders`, `/api/v1/orders/{orderId}/lines`.
  Verbs go in the HTTP method, not the path. Exception: genuine commands that
  are not CRUD may use `POST /api/v1/orders/{id}/cancellation`.
- Status codes: 201 + `Location` on create, 204 on a command with no body,
  409 on an invariant/state conflict, 422 on semantic validation failure,
  400 on malformed input.
- Errors use RFC 7807 `application/problem+json` via the shared
  `@RestControllerAdvice` in `shared/error`. Never return a raw stack trace or
  an exception message from the domain straight to the client.
- Breaking a published contract requires a new version path and an ADR.
- Every endpoint carries OpenAPI annotations; the generated spec is the contract.
