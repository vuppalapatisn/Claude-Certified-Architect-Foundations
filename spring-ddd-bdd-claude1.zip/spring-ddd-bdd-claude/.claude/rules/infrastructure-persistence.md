---
paths:
  - "src/main/java/**/infrastructure/**/*.java"
  - "src/main/resources/db/migration/**/*.sql"
---

# Persistence and adapter rules

## Mapping

- JPA entities are separate classes from aggregates, suffixed `JpaEntity`, and
  live only in `infrastructure/persistence`. They may use Lombok and JPA
  annotations freely.
- A `Mapper` converts both ways. The aggregate never knows the entity exists.
- The adapter implements the domain port and is suffixed `Adapter`
  (`OrderRepositoryAdapter implements OrderRepository`).
- Spring Data interfaces are internal to this package and never injected into
  the application layer.

## Migrations

- Flyway. Files are `V{n}__{snake_case_description}.sql`, sequential, additive.
- Never edit an applied migration. Correct it with a new one.
- Every column addition is nullable or has a default — no table rewrites on
  large tables, no blocking DDL in a single deploy window.
- Index anything used in a `WHERE` or a foreign key.
- Destructive change (drop column/table) needs an ADR and a two-deploy plan:
  stop writing, then drop.

## Queries

- Read models for queries may bypass the aggregate and project directly with a
  DTO projection. Write paths must go through the aggregate.
- No `SELECT *`. No string-concatenated SQL. Parameter binding always.
