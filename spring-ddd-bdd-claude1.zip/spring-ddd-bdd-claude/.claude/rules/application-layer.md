---
paths:
  - "src/main/java/**/application/**/*.java"
---

# Application layer rules

## Use cases

- One class per use case, named `{Verb}{Noun}Service` implementing a
  `{Verb}{Noun}UseCase` interface. No `OrderService` god class.
- Input is a command record; output is a result record or a typed ID.
  Never accept or return a REST DTO, a JPA entity, or an aggregate root.
- The service is the transaction boundary: `@Transactional` lives here, not on
  the controller and not on the repository adapter.

## Shape of a use case

```
1. Load the aggregate through its port (or fail with NotFound).
2. Call one intention-revealing method on the aggregate.
3. Save through the port.
4. Publish recorded domain events.
```

Business rules that appear in step 1 or 3 are in the wrong layer — push them
into the aggregate.

## Constraints

- One aggregate mutated per transaction. Coordinate the rest with events.
- Constructor injection of ports only. No `@Autowired` fields.
- No SQL, no `EntityManager`, no HTTP clients here.
- Map port exceptions into application-level failures; do not let a
  `DataIntegrityViolationException` escape to the controller.
