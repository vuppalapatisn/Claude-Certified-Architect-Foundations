---
paths:
  - "src/test/resources/features/**/*.feature"
  - "src/test/java/**/bdd/**/*.java"
---

# BDD rules

## Feature files

- Written in business language from `docs/requirements/glossary-ubiquitous-language.md`.
  A domain expert must be able to read a scenario without a developer present.
- Structure: `Feature` states the capability and its value; each `Scenario` is
  one concrete, observable behaviour.
- Declarative, not imperative. Describe intent, not clicks or payloads.
  - Good: `When the customer places an order for 3 units of "SKU-100"`
  - Bad: `When I POST {"sku":"SKU-100","qty":3} to /api/v1/orders`
- One `When` per scenario. Multiple `When`s mean two scenarios.
- No technical leakage: no HTTP verbs, SQL, JSON, CSS selectors, or table names
  in the Gherkin. Those belong in step definitions.
- `Scenario Outline` with `Examples` for the same rule across different data.
  Do not use it to merge unrelated behaviours.
- Tags: `@smoke`, `@regression`, `@wip`, plus the requirement ID (`@FR-012`)
  so features trace back to `docs/requirements/functional-requirements.md`.

## Step definitions

- Live in `src/test/java/**/bdd/steps`. Thin glue only — they translate a
  sentence into a call against the application, and assert on the result.
- No assertions in `Given`. No new business logic in steps; if a step needs a
  rule, the rule belongs in the domain.
- Share state through an injected scenario-scoped context object, never static
  fields.
- Reuse existing step phrasing before inventing new wording. Run
  `./mvnw verify -Pbdd` and check for undefined/ambiguous steps.

## Workflow for new behaviour

1. Write or update the scenario, tagged with its requirement ID.
2. Run it. Confirm it fails for the right reason.
3. Drive out the domain model with unit tests.
4. Wire the application service, then the adapters.
5. Re-run the scenario until green. Keep the scenario unchanged while doing so —
   if the scenario has to change to pass, the requirement was misunderstood.
