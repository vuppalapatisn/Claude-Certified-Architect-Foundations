# Security rules (always loaded)

- Never commit a credential, token, keystore, or connection string with a
  password. Configuration comes from environment variables or the secrets
  manager, referenced as `${ORDERS_DB_PASSWORD}` in `application.yml`.
- Never log PII (customer name, email, address) or a full payment identifier.
  Log the `OrderId`, not the order contents.
- All external input is validated at the boundary before it reaches a use case.
- Authorization is checked in the application layer against the use case, not
  in the controller and not in the domain.
- SQL is always parameterized. No string concatenation into a query.
- Dependencies with known critical CVEs block the build; do not suppress a
  finding without an ADR recording the accepted risk.
- If you notice a secret in the repository history, stop and tell the human.
  Do not attempt to rewrite history.
