---
paths:
  - "src/test/java/**/*.java"
---

# Test rules

## Pyramid

| Level | Tool | Spring context | Speed target |
| --- | --- | --- | --- |
| Domain unit | JUnit 5 + AssertJ | none | < 10 ms each |
| Use case | JUnit 5 + Mockito | none | < 50 ms each |
| Adapter slice | `@DataJpaTest`, `@WebMvcTest` | sliced | < 2 s each |
| Acceptance | Cucumber + Testcontainers | full | minutes, few in number |

Reach for the lowest level that can fail for the right reason. A rule that can
be tested in the domain must not be tested through HTTP.

## Style

- Name tests as behaviour: `cancellingAShippedOrderIsRejected()`. Not `testCancel1`.
- Arrange/Act/Assert, separated by blank lines. One logical assertion per test.
- AssertJ (`assertThat`). No bare JUnit `assertEquals`.
- Test data through builders or object mothers in `src/test/java/**/support`.
  No shared mutable fixtures between tests.
- No mocking of value objects or aggregates. Mock ports only.
- No `Thread.sleep`. Use Awaitility for async assertions.
- Deterministic: fixed `Clock`, fixed seeds, no reliance on test ordering.

## Coverage

Domain package: meaningful branch coverage expected. Elsewhere, coverage is a
diagnostic, not a target — do not write tests solely to raise the number.
