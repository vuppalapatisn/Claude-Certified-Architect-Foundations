---
paths:
  - "src/main/java/**/domain/**/*.java"
---

# Domain layer rules

Loaded only when Claude reads a file under a `domain` package.

## Purity

- Plain Java. No Spring, no JPA, no Jackson, no Lombok, no logging framework.
- No `java.time.LocalDateTime.now()` inside the aggregate — take a `Clock` or
  pass the timestamp in. Time is an input, not an ambient fact.
- No I/O. No repository calls from inside an aggregate.

## Aggregates

- One aggregate root per consistency boundary. `Order` is the root; `OrderLine`
  is reachable only through it.
- Private no-arg constructor for mapping only if unavoidable; prefer a static
  factory (`Order.place(...)`) that validates and returns a valid instance.
- No public setters. Every mutation is a named behaviour that:
  1. validates the invariant,
  2. mutates state,
  3. records a domain event via `registerEvent(...)`.
- Throw `DomainRuleViolation` (in `shared/error`) for invariant breaches, never
  `IllegalArgumentException` for business rules. Use `IllegalArgumentException`
  only for programmer error such as a null argument.
- Reference other aggregates by ID only (`CustomerId`), never by object.

## Value objects

- Java records. Validate in a compact constructor. Immutable, no identity.
- Equality is by value — records give this for free, so do not override `equals`.
- Self-validating: `new Quantity(-1)` must throw, not produce a bad object.

## Domain events

- Past tense, named for the business fact: `OrderPlaced`, `OrderCancelled`.
- Immutable records carrying IDs and primitives, never aggregate references.
- Members of a sealed interface `DomainEvent` so exhaustive switches work.
- Recorded by the aggregate, published by the application layer after commit.
