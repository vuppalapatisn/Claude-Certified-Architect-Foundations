---
paths:
  - "pom.xml"
  - ".github/workflows/**"
---

# Build and dependency rules

- Versions are managed in `<dependencyManagement>` or by the Spring Boot BOM.
  No version numbers scattered in individual `<dependency>` blocks.
- Adding a dependency requires: a stated reason, a licence check, and an ADR if
  it introduces a new architectural capability (messaging, caching, a new DB).
  Ask before adding.
- Prefer the standard library or an existing dependency over a new one.
- No `SNAPSHOT` dependencies on a release branch.
- CI must run the same commands a developer runs locally. If CI needs a special
  flag, add it to `CLAUDE.md` too so local runs match.
- Keep `spotless`, `checkstyle`, and the architecture test in the `verify`
  lifecycle so a violation fails the build rather than a review comment.
