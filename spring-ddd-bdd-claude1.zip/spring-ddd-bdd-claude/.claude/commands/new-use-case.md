---
description: Implement a use case end to end, outside in, starting from the scenario
argument-hint: <UseCaseName> [requirement-id]
---

Implement the `$1` use case. Requirement: ${2:unspecified — ask me for it}.

Work outside in and stop at each checkpoint:

**Checkpoint 1 — specification.** Locate the requirement in
`docs/requirements/functional-requirements.md`. Write or update the Gherkin
scenario in `src/test/resources/features/`, tagged with the requirement ID.
Run `./mvnw verify -Pbdd` and show me the failure. Do not continue until I approve
the scenario wording.

**Checkpoint 2 — domain.** Drive the behaviour into the aggregate with unit
tests. No Spring, no persistence. Show me the aggregate diff.

**Checkpoint 3 — application.** Add the command record, the `$1UseCase`
interface and `$1Service` implementation. Mockito tests for the orchestration,
including the failure paths.

**Checkpoint 4 — adapters.** Persistence mapping and migration if the schema
changes; controller, DTOs and OpenAPI annotations; slice tests for each.

**Checkpoint 5 — green.** Run `./mvnw verify -Pbdd`. Report what changed and
anything you had to assume.
