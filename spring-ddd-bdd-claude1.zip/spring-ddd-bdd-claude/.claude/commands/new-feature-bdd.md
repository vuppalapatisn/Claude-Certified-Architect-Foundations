---
description: Turn a plain-language requirement into a reviewable Gherkin feature
argument-hint: <requirement description>
---

Requirement: $ARGUMENTS

Produce a feature file following `.claude/rules/bdd-gherkin.md`.

First, interrogate the requirement rather than accepting it:
- What are the boundary values, and what happens exactly at each boundary?
- What are the failure and rejection paths?
- Which existing rules in `docs/requirements/functional-requirements.md` does
  this contradict or overlap with?
- Which terms are not yet in the glossary?

List those questions and stop. After I answer, write the feature file with:
a `Feature` block stating the capability and its business value, the happy path,
every rejection case, and a `Scenario Outline` where the same rule spans several
data points. Assign the next free `FR-` id and add the requirement to
`docs/requirements/functional-requirements.md` in the same change.

Do not write step definitions or production code.
