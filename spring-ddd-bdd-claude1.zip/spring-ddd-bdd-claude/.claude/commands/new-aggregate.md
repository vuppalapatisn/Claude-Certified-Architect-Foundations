---
description: Scaffold a new DDD aggregate with value objects, events, port and tests
argument-hint: <AggregateName> [bounded-context]
---

Create a new aggregate named `$1` in the `${2:-ordering}` bounded context.

Before writing any code:
1. Read `docs/ddd/aggregates.md` and `docs/requirements/glossary-ubiquitous-language.md`.
2. State the consistency boundary: what invariants must hold within a single
   transaction, and what is explicitly allowed to be eventually consistent.
3. List the value objects, the identity type, and the domain events you intend
   to create. Wait for my confirmation before proceeding.

Then produce, in this order:
- `domain/model/$1Id.java` — typed identity as a record
- `domain/model/$1.java` — aggregate root, static factory, no setters,
  behaviours that validate then record events
- `domain/event/` — one record per business fact, added to the `DomainEvent`
  sealed interface
- `domain/port/$1Repository.java` — `findById`, `save`, nothing speculative
- `src/test/java/**/domain/$1Test.java` — one test per invariant, including the
  failure cases
- An entry in `docs/ddd/aggregates.md` describing the boundary and invariants

Do not create the JPA entity, the adapter, or the controller in this command.
Stop after the domain is green so we can review the model first.
