---
description: Audit the working tree against the DDD and hexagonal rules
---

Review the current changes (`git diff` against the base branch) strictly
against `.claude/rules/00-architecture.md` and `.claude/rules/domain-layer.md`.

Check specifically:
- Imports crossing a layer boundary in the wrong direction
- Framework or persistence annotations inside `domain`
- Public setters or exposed mutable collections on an aggregate
- Business rules that have leaked into a controller, service, or step definition
- More than one aggregate mutated in a single transaction
- Anaemic aggregates: data holders with all logic in a service
- Names not present in the glossary
- Ports declared outside `domain/port`, or adapters injected into `application`

Output a table: file, line, rule violated, severity, suggested fix. Then list
anything that is technically compliant but that you would question in review,
separately, so I can tell the two apart. Do not change any code.
