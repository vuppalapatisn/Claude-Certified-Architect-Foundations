---
description: Prepare a pull request description from the actual diff
---

Run `./mvnw verify` first. If it fails, stop and report the failure — do not
write a PR description for a broken build.

Then read `git diff` against the base branch and write a description with:
- **Why** — the requirement or defect, with its ID
- **What changed** — grouped by layer (domain / application / adapters / docs),
  not a file list
- **Domain model impact** — new or changed aggregates, invariants, events
- **Contract impact** — REST or event payload changes, and whether they break
  consumers
- **Migrations** — each migration, and whether it is reversible
- **Tests** — which scenarios and unit tests cover the change
- **Assumptions and follow-ups** — anything you inferred rather than confirmed

Use the checklist from `.github/pull_request_template.md` and tick only what is
actually true of this diff. Write it to the terminal; do not push or open the PR.
