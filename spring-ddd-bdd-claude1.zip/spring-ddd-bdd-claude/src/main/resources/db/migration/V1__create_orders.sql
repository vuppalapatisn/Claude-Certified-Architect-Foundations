-- V1: initial schema for the Ordering context.
-- Applied migrations are never edited. Corrections go in a new V{n} file.

CREATE TABLE orders (
    id          UUID        PRIMARY KEY,
    customer_id UUID        NOT NULL,
    status      VARCHAR(20) NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE order_lines (
    order_id   UUID           NOT NULL REFERENCES orders (id),
    sku        VARCHAR(64)    NOT NULL,
    quantity   INTEGER        NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(19, 4) NOT NULL CHECK (unit_price >= 0),
    currency   CHAR(3)        NOT NULL
);

-- Indexed because every read path filters on it (NFR-001).
CREATE INDEX idx_orders_customer_id ON orders (customer_id);
CREATE INDEX idx_order_lines_order_id ON order_lines (order_id);

-- Transactional outbox: a committed fact is never lost (NFR-004).
CREATE TABLE outbox (
    id           BIGSERIAL   PRIMARY KEY,
    aggregate_id UUID        NOT NULL,
    event_type   VARCHAR(64) NOT NULL,
    payload      JSONB       NOT NULL,
    occurred_at  TIMESTAMPTZ NOT NULL,
    published_at TIMESTAMPTZ
);

CREATE INDEX idx_outbox_unpublished ON outbox (id) WHERE published_at IS NULL;
