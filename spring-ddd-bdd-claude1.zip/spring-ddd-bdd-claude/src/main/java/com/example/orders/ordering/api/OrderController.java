package com.example.orders.ordering.api;

import com.example.orders.ordering.api.dto.OrderResponse;
import com.example.orders.ordering.api.dto.PlaceOrderRequest;
import com.example.orders.ordering.application.command.CancelOrderCommand;
import com.example.orders.ordering.application.command.CancelOrderUseCase;
import com.example.orders.ordering.application.command.PlaceOrderCommand;
import com.example.orders.ordering.application.command.PlaceOrderUseCase;
import com.example.orders.ordering.domain.model.OrderId;
import com.example.orders.ordering.domain.port.OrderRepository;
import com.example.orders.shared.error.OrderNotFound;
import jakarta.validation.Valid;
import java.net.URI;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

/** Thin: deserialize, delegate to one use case, map the result. No @Transactional. */
@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {

  private final PlaceOrderUseCase placeOrder;
  private final CancelOrderUseCase cancelOrder;
  private final OrderRepository orders; // read path may query directly

  public OrderController(
      PlaceOrderUseCase placeOrder, CancelOrderUseCase cancelOrder, OrderRepository orders) {
    this.placeOrder = placeOrder;
    this.cancelOrder = cancelOrder;
    this.orders = orders;
  }

  @PostMapping
  public ResponseEntity<Void> place(
      @Valid @RequestBody PlaceOrderRequest request,
      @RequestParam(value = "idempotencyKey", required = false) String idempotencyKey) {

    OrderId id =
        placeOrder.place(
            new PlaceOrderCommand(
                request.customerId(),
                request.lines().stream()
                    .map(
                        l ->
                            new PlaceOrderCommand.Line(
                                l.sku(), l.quantity(), l.unitPrice(), l.currency()))
                    .toList(),
                idempotencyKey));

    return ResponseEntity.created(URI.create("/api/v1/orders/" + id)).build();
  }

  @GetMapping("/{orderId}")
  public OrderResponse get(@PathVariable String orderId) {
    return orders
        .findById(OrderId.of(orderId))
        .map(OrderResponse::from)
        .orElseThrow(() -> new OrderNotFound(orderId));
  }

  /** A genuine command, not CRUD: POST a cancellation rather than PATCH a status. */
  @PostMapping("/{orderId}/cancellation")
  public ResponseEntity<Void> cancel(
      @PathVariable String orderId, @RequestParam("reason") String reason) {
    cancelOrder.cancel(new CancelOrderCommand(orderId, reason));
    return ResponseEntity.noContent().build();
  }
}
