package com.example.orders.ordering.infrastructure.persistence;

import com.example.orders.ordering.domain.model.CustomerId;
import com.example.orders.ordering.domain.model.Money;
import com.example.orders.ordering.domain.model.Order;
import com.example.orders.ordering.domain.model.OrderId;
import com.example.orders.ordering.domain.model.OrderLine;
import com.example.orders.ordering.domain.model.OrderStatus;
import com.example.orders.ordering.domain.model.Quantity;
import com.example.orders.ordering.domain.model.Sku;
import java.util.Currency;
import java.util.List;

/** Translates both ways. The aggregate does not know the entity exists. */
final class OrderMapper {

  private OrderMapper() {}

  static OrderJpaEntity toEntity(Order order) {
    List<OrderJpaEntity.LineEmbeddable> lines =
        order.lines().stream()
            .map(
                l ->
                    new OrderJpaEntity.LineEmbeddable(
                        l.sku().value(),
                        l.quantity().value(),
                        l.unitPrice().amount(),
                        l.unitPrice().currency().getCurrencyCode()))
            .toList();

    return new OrderJpaEntity(
        order.id().value(), order.customerId().value(), order.status().name(), lines);
  }

  static Order toDomain(OrderJpaEntity entity) {
    List<OrderLine> lines =
        entity.getLines().stream()
            .map(
                l ->
                    new OrderLine(
                        new Sku(l.getSku()),
                        new Quantity(l.getQuantity()),
                        new Money(l.getUnitPrice(), Currency.getInstance(l.getCurrency()))))
            .toList();

    return Order.rehydrate(
        new OrderId(entity.getId()),
        new CustomerId(entity.getCustomerId()),
        lines,
        OrderStatus.valueOf(entity.getStatus()));
  }
}
