package com.example.orders.ordering.domain.model;

import java.util.UUID;

public record CustomerId(UUID value) {
  public CustomerId {
    if (value == null) {
      throw new IllegalArgumentException("CustomerId value is required");
    }
  }

  public static CustomerId of(String raw) {
    return new CustomerId(UUID.fromString(raw));
  }
}
