package com.example.orders.ordering.api.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import java.util.List;

public record PlaceOrderRequest(
    @NotBlank String customerId, @NotEmpty @Valid List<Line> lines) {

  public record Line(
      @NotBlank String sku,
      @Positive int quantity,
      @NotBlank String unitPrice,
      @NotBlank String currency) {}
}
