package com.example.orders.ordering.domain.model;

import com.example.orders.ordering.domain.event.DomainEvent;
import com.example.orders.ordering.domain.event.OrderCancelled;
import com.example.orders.ordering.domain.event.OrderPlaced;
import com.example.orders.shared.error.DomainRuleViolation;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Aggregate root for the Ordering context.
 *
 * <p>Invariants held transactionally: at least one line (FR-001); positive quantities
 * (FR-002, enforced by {@link Quantity}); single currency (FR-004); total is the sum of
 * subtotals (FR-005); status transitions follow the permitted graph (FR-010, FR-011).
 *
 * <p>No framework annotations. No setters. Time is an input, never read from a clock here.
 */
public final class Order {

  private final OrderId id;
  private final CustomerId customerId;
  private final List<OrderLine> lines;
  private OrderStatus status;
  private final List<DomainEvent> events = new ArrayList<>();

  private Order(OrderId id, CustomerId customerId, List<OrderLine> lines, OrderStatus status) {
    this.id = id;
    this.customerId = customerId;
    this.lines = new ArrayList<>(lines);
    this.status = status;
  }

  /** The only way to create a new order. Returns a valid instance or throws. */
  public static Order place(
      OrderId id, CustomerId customerId, List<OrderLine> lines, Instant placedAt) {
    if (lines == null || lines.isEmpty()) {
      throw new DomainRuleViolation("An order must contain at least one line");
    }
    Order order = new Order(id, customerId, lines, OrderStatus.PLACED);
    Money total = order.total(); // throws if currencies are mixed (FR-004)
    order.events.add(new OrderPlaced(id, customerId, total, placedAt));
    return order;
  }

  /** Reconstitution from storage. No validation of history, no events. */
  public static Order rehydrate(
      OrderId id, CustomerId customerId, List<OrderLine> lines, OrderStatus status) {
    return new Order(id, customerId, lines, status);
  }

  /** FR-010, FR-011, FR-012: validate the transition, mutate, record the fact. */
  public void cancel(CancellationReason reason, Instant occurredAt) {
    if (reason == null) {
      throw new DomainRuleViolation("A cancellation reason is required");
    }
    if (status == OrderStatus.CANCELLED) {
      return; // FR-012: idempotent, not an error
    }
    if (!status.isCancellable()) {
      throw new DomainRuleViolation("An order that is " + status + " cannot be cancelled");
    }
    this.status = OrderStatus.CANCELLED;
    this.events.add(new OrderCancelled(id, reason, occurredAt));
  }

  /** FR-005. Throws if the lines do not share one currency. */
  public Money total() {
    return lines.stream()
        .map(OrderLine::subtotal)
        .reduce(Money::plus)
        .orElseThrow(() -> new DomainRuleViolation("An order must contain at least one line"));
  }

  public OrderId id() {
    return id;
  }

  public CustomerId customerId() {
    return customerId;
  }

  public OrderStatus status() {
    return status;
  }

  /** Defensive copy — callers cannot mutate the aggregate's internals. */
  public List<OrderLine> lines() {
    return List.copyOf(lines);
  }

  /** Drained by the application service after a successful commit. */
  public List<DomainEvent> pullEvents() {
    List<DomainEvent> pulled = List.copyOf(events);
    events.clear();
    return pulled;
  }
}
