package com.example.orders.ordering.domain.model;

import java.util.UUID;

/** Typed identity. Never pass a bare UUID or String across a boundary. */
public record OrderId(UUID value) {
  public OrderId {
    if (value == null) {
      throw new IllegalArgumentException("OrderId value is required");
    }
  }

  public static OrderId generate() {
    return new OrderId(UUID.randomUUID());
  }

  public static OrderId of(String raw) {
    return new OrderId(UUID.fromString(raw));
  }

  @Override
  public String toString() {
    return value.toString();
  }
}
