package com.example.orders.ordering.application.service;

import com.example.orders.ordering.application.command.PlaceOrderCommand;
import com.example.orders.ordering.application.command.PlaceOrderUseCase;
import com.example.orders.ordering.domain.model.CustomerId;
import com.example.orders.ordering.domain.model.Money;
import com.example.orders.ordering.domain.model.Order;
import com.example.orders.ordering.domain.model.OrderId;
import com.example.orders.ordering.domain.model.OrderLine;
import com.example.orders.ordering.domain.model.Quantity;
import com.example.orders.ordering.domain.model.Sku;
import com.example.orders.ordering.domain.port.DomainEventPublisher;
import com.example.orders.ordering.domain.port.OrderRepository;
import java.time.Clock;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Transaction boundary for placing an order. Orchestrates only: load/create,
 * one call into the aggregate, save, publish. No business rules live here.
 */
@Service
public class PlaceOrderService implements PlaceOrderUseCase {

  private final OrderRepository orders;
  private final DomainEventPublisher publisher;
  private final Clock clock;

  public PlaceOrderService(OrderRepository orders, DomainEventPublisher publisher, Clock clock) {
    this.orders = orders;
    this.publisher = publisher;
    this.clock = clock;
  }

  @Override
  @Transactional
  public OrderId place(PlaceOrderCommand command) {
    List<OrderLine> lines = command.lines().stream().map(PlaceOrderService::toLine).toList();

    Order order =
        Order.place(OrderId.generate(), CustomerId.of(command.customerId()), lines, clock.instant());

    orders.save(order);
    publisher.publish(order.pullEvents());
    return order.id();
  }

  private static OrderLine toLine(PlaceOrderCommand.Line line) {
    return new OrderLine(
        new Sku(line.sku()),
        new Quantity(line.quantity()),
        Money.of(line.unitPrice(), line.currency()));
  }
}
