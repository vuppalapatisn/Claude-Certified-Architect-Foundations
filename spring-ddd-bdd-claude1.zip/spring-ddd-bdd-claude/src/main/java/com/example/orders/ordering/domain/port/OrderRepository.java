package com.example.orders.ordering.domain.port;

import com.example.orders.ordering.domain.model.Order;
import com.example.orders.ordering.domain.model.OrderId;
import java.util.Optional;

/**
 * Port. Declared in the domain, implemented in infrastructure. One repository per
 * aggregate, not per table. Nothing speculative — add methods when a use case needs them.
 */
public interface OrderRepository {
  Optional<Order> findById(OrderId id);

  void save(Order order);
}
