package com.example.orders.ordering.application.command;

public interface CancelOrderUseCase {
  void cancel(CancelOrderCommand command);
}
