package com.example.orders.ordering.domain.model;

/**
 * Entity within the Order aggregate. Reachable only through the root.
 * FR-003: unitPrice is captured at placement and never changes.
 */
public record OrderLine(Sku sku, Quantity quantity, Money unitPrice) {

  public OrderLine {
    if (sku == null || quantity == null || unitPrice == null) {
      throw new IllegalArgumentException("An order line requires a sku, quantity and unit price");
    }
  }

  public Money subtotal() {
    return unitPrice.times(quantity.value());
  }
}
