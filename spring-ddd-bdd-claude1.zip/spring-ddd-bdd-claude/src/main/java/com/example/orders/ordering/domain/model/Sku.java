package com.example.orders.ordering.domain.model;

public record Sku(String value) {
  public Sku {
    if (value == null || value.isBlank()) {
      throw new IllegalArgumentException("Sku is required");
    }
  }
}
