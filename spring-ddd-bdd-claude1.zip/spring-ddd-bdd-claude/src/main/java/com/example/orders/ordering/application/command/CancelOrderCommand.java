package com.example.orders.ordering.application.command;

public record CancelOrderCommand(String orderId, String reason) {}
