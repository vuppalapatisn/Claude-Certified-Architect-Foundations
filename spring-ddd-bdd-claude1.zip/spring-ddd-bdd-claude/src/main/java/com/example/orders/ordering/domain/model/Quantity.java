package com.example.orders.ordering.domain.model;

import com.example.orders.shared.error.DomainRuleViolation;

/** FR-002: a line quantity is a positive integer. Self-validating. */
public record Quantity(int value) {
  public Quantity {
    if (value <= 0) {
      throw new DomainRuleViolation("Quantity must be positive, was " + value);
    }
  }
}
