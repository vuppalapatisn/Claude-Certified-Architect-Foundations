package com.example.orders.ordering.domain.event;

import com.example.orders.ordering.domain.model.CustomerId;
import com.example.orders.ordering.domain.model.Money;
import com.example.orders.ordering.domain.model.OrderId;
import java.time.Instant;

/** FR-006. Carries IDs and values only — never an aggregate reference. */
public record OrderPlaced(OrderId orderId, CustomerId customerId, Money total, Instant occurredAt)
    implements DomainEvent {}
