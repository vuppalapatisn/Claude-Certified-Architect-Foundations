package com.example.orders.ordering.domain.event;

import java.time.Instant;

/** Sealed so consumers can switch exhaustively over the known business facts. */
public sealed interface DomainEvent permits OrderPlaced, OrderCancelled {
  Instant occurredAt();
}
