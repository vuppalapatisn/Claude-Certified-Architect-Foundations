package com.example.orders.shared.error;

public class OrderNotFound extends RuntimeException {
  public OrderNotFound(String orderId) {
    super("No order with id " + orderId);
  }
}
