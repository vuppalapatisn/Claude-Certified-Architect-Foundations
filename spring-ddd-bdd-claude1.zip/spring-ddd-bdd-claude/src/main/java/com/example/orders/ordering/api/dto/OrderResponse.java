package com.example.orders.ordering.api.dto;

import com.example.orders.ordering.domain.model.Order;
import java.util.List;

public record OrderResponse(
    String orderId, String customerId, String status, String total, String currency, List<Line> lines) {

  public record Line(String sku, int quantity, String unitPrice) {}

  public static OrderResponse from(Order order) {
    return new OrderResponse(
        order.id().toString(),
        order.customerId().value().toString(),
        order.status().name(),
        order.total().amount().toPlainString(),
        order.total().currency().getCurrencyCode(),
        order.lines().stream()
            .map(
                l ->
                    new Line(
                        l.sku().value(), l.quantity().value(), l.unitPrice().amount().toPlainString()))
            .toList());
  }
}
