package com.example.orders.ordering.infrastructure.persistence;

import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

/** Internal to this package. Never injected into the application layer. */
interface SpringDataOrderRepository extends JpaRepository<OrderJpaEntity, UUID> {}
