package com.example.orders.ordering.domain.event;

import com.example.orders.ordering.domain.model.CancellationReason;
import com.example.orders.ordering.domain.model.OrderId;
import java.time.Instant;

/** FR-014. */
public record OrderCancelled(OrderId orderId, CancellationReason reason, Instant occurredAt)
    implements DomainEvent {}
