package com.example.orders.ordering.domain.model;

/** FR-013: cancellation requires a reason from this fixed set. No free text. */
public enum CancellationReason {
  CUSTOMER_CHANGED_MIND,
  PAYMENT_FAILED,
  FRAUD_SUSPECTED,
  STOCK_UNAVAILABLE
}
