package com.example.orders.ordering.application.command;

import java.util.List;

/** Input to the use case. Not a REST DTO, not an entity. */
public record PlaceOrderCommand(String customerId, List<Line> lines, String idempotencyKey) {
  public record Line(String sku, int quantity, String unitPrice, String currency) {}
}
