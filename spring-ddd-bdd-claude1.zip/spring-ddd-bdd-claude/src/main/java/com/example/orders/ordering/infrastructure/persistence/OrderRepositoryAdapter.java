package com.example.orders.ordering.infrastructure.persistence;

import com.example.orders.ordering.domain.model.Order;
import com.example.orders.ordering.domain.model.OrderId;
import com.example.orders.ordering.domain.port.OrderRepository;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** Implements the domain port. Suffix is Adapter by convention. */
@Repository
public class OrderRepositoryAdapter implements OrderRepository {

  private final SpringDataOrderRepository jpa;

  OrderRepositoryAdapter(SpringDataOrderRepository jpa) {
    this.jpa = jpa;
  }

  @Override
  public Optional<Order> findById(OrderId id) {
    return jpa.findById(id.value()).map(OrderMapper::toDomain);
  }

  @Override
  public void save(Order order) {
    jpa.save(OrderMapper.toEntity(order));
  }
}
