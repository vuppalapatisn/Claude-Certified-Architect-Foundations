package com.example.orders.ordering.domain.port;

import com.example.orders.ordering.domain.event.DomainEvent;
import java.util.List;

/** Port for publishing committed facts. Implemented by the outbox adapter. */
public interface DomainEventPublisher {
  void publish(List<DomainEvent> events);
}
