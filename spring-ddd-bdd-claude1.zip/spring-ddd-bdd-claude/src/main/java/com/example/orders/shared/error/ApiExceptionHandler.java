package com.example.orders.shared.error;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/** RFC 7807 responses. Never leaks a stack trace or an internal message. */
@RestControllerAdvice
public class ApiExceptionHandler {

  @ExceptionHandler(DomainRuleViolation.class)
  ProblemDetail onRuleViolation(DomainRuleViolation ex) {
    ProblemDetail detail = ProblemDetail.forStatus(HttpStatus.CONFLICT);
    detail.setTitle("Business rule violated");
    detail.setDetail(ex.getMessage());
    return detail;
  }

  @ExceptionHandler(OrderNotFound.class)
  ProblemDetail onNotFound(OrderNotFound ex) {
    ProblemDetail detail = ProblemDetail.forStatus(HttpStatus.NOT_FOUND);
    detail.setTitle("Order not found");
    return detail;
  }
}
