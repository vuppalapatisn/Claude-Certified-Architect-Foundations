package com.example.orders.ordering.domain.model;

/** FR-010, FR-011: the permitted lifecycle. Cancellable only before shipping. */
public enum OrderStatus {
  PLACED(true),
  PICKED(true),
  PACKED(true),
  SHIPPED(false),
  DELIVERED(false),
  CANCELLED(false);

  private final boolean cancellable;

  OrderStatus(boolean cancellable) {
    this.cancellable = cancellable;
  }

  public boolean isCancellable() {
    return cancellable;
  }
}
