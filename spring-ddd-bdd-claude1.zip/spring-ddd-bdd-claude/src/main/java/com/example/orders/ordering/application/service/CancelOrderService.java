package com.example.orders.ordering.application.service;

import com.example.orders.ordering.application.command.CancelOrderCommand;
import com.example.orders.ordering.application.command.CancelOrderUseCase;
import com.example.orders.ordering.domain.model.CancellationReason;
import com.example.orders.ordering.domain.model.Order;
import com.example.orders.ordering.domain.model.OrderId;
import com.example.orders.ordering.domain.port.DomainEventPublisher;
import com.example.orders.ordering.domain.port.OrderRepository;
import com.example.orders.shared.error.OrderNotFound;
import java.time.Clock;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CancelOrderService implements CancelOrderUseCase {

  private final OrderRepository orders;
  private final DomainEventPublisher publisher;
  private final Clock clock;

  public CancelOrderService(OrderRepository orders, DomainEventPublisher publisher, Clock clock) {
    this.orders = orders;
    this.publisher = publisher;
    this.clock = clock;
  }

  @Override
  @Transactional
  public void cancel(CancelOrderCommand command) {
    OrderId id = OrderId.of(command.orderId());
    Order order = orders.findById(id).orElseThrow(() -> new OrderNotFound(command.orderId()));

    // The decision about whether this is permitted belongs to the aggregate.
    order.cancel(CancellationReason.valueOf(command.reason()), clock.instant());

    orders.save(order);
    publisher.publish(order.pullEvents());
  }
}
