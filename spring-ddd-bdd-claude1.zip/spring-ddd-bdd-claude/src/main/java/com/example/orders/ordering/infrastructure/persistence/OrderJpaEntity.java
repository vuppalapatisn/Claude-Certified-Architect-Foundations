package com.example.orders.ordering.infrastructure.persistence;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Persistence representation — a separate class from the aggregate on purpose (ADR-0002).
 * JPA and Lombok annotations are allowed here and nowhere in the domain.
 */
@Entity
@Table(name = "orders")
public class OrderJpaEntity {

  @Id
  @Column(name = "id", nullable = false)
  private UUID id;

  @Column(name = "customer_id", nullable = false)
  private UUID customerId;

  @Column(name = "status", nullable = false, length = 20)
  @Enumerated(EnumType.STRING)
  private String status;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(name = "order_lines", joinColumns = @JoinColumn(name = "order_id"))
  private List<LineEmbeddable> lines = new ArrayList<>();

  protected OrderJpaEntity() {}

  public OrderJpaEntity(UUID id, UUID customerId, String status, List<LineEmbeddable> lines) {
    this.id = id;
    this.customerId = customerId;
    this.status = status;
    this.lines = lines;
  }

  public UUID getId() {
    return id;
  }

  public UUID getCustomerId() {
    return customerId;
  }

  public String getStatus() {
    return status;
  }

  public List<LineEmbeddable> getLines() {
    return lines;
  }

  @Embeddable
  public static class LineEmbeddable {
    @Column(name = "sku", nullable = false)
    private String sku;

    @Column(name = "quantity", nullable = false)
    private int quantity;

    @Column(name = "unit_price", nullable = false, precision = 19, scale = 4)
    private BigDecimal unitPrice;

    @Column(name = "currency", nullable = false, length = 3)
    private String currency;

    protected LineEmbeddable() {}

    public LineEmbeddable(String sku, int quantity, BigDecimal unitPrice, String currency) {
      this.sku = sku;
      this.quantity = quantity;
      this.unitPrice = unitPrice;
      this.currency = currency;
    }

    public String getSku() {
      return sku;
    }

    public int getQuantity() {
      return quantity;
    }

    public BigDecimal getUnitPrice() {
      return unitPrice;
    }

    public String getCurrency() {
      return currency;
    }
  }
}
