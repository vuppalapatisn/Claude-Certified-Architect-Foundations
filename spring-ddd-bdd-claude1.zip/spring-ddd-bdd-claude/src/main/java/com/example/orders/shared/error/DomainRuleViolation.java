package com.example.orders.shared.error;

/**
 * Thrown when a business invariant would be broken. Distinct from
 * IllegalArgumentException, which signals programmer error such as a null argument.
 * Mapped to HTTP 409 by the API error handler.
 */
public class DomainRuleViolation extends RuntimeException {
  public DomainRuleViolation(String message) {
    super(message);
  }
}
