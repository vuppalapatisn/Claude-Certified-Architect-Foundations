package com.example.orders.ordering.application.command;

import com.example.orders.ordering.domain.model.OrderId;

public interface PlaceOrderUseCase {
  OrderId place(PlaceOrderCommand command);
}
