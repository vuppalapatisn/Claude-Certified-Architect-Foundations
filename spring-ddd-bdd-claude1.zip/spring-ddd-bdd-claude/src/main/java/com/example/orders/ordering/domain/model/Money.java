package com.example.orders.ordering.domain.model;

import com.example.orders.shared.error.DomainRuleViolation;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;

/** Amount paired with a currency. Never a double, never a bare BigDecimal. */
public record Money(BigDecimal amount, Currency currency) {

  public Money {
    if (amount == null || currency == null) {
      throw new IllegalArgumentException("Money requires an amount and a currency");
    }
    if (amount.signum() < 0) {
      throw new DomainRuleViolation("Money cannot be negative");
    }
    amount = amount.setScale(currency.getDefaultFractionDigits(), RoundingMode.HALF_UP);
  }

  public static Money of(String amount, String currencyCode) {
    return new Money(new BigDecimal(amount), Currency.getInstance(currencyCode));
  }

  public static Money zero(Currency currency) {
    return new Money(BigDecimal.ZERO, currency);
  }

  public Money plus(Money other) {
    requireSameCurrency(other);
    return new Money(amount.add(other.amount), currency);
  }

  public Money times(int factor) {
    return new Money(amount.multiply(BigDecimal.valueOf(factor)), currency);
  }

  private void requireSameCurrency(Money other) {
    if (!currency.equals(other.currency)) {
      // FR-004: mixed currencies are rejected rather than converted.
      throw new DomainRuleViolation(
          "Cannot combine " + currency.getCurrencyCode() + " with " + other.currency.getCurrencyCode());
    }
  }
}
