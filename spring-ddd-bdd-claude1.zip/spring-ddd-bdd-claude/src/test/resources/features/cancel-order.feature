Feature: Order cancellation
  So that customers are not charged for goods they no longer want,
  an order may be cancelled at any point before it ships.

  Background:
    Given a customer "Ada" with a placed order for 3 units of "SKU-100" at 10.00 EUR

  @FR-010 @smoke
  Scenario Outline: The cancellation window closes at shipping
    Given the order is <state>
    When Ada cancels the order because she changed her mind
    Then the cancellation is <outcome>

    Examples:
      | state     | outcome  |
      | placed    | accepted |
      | picked    | accepted |
      | packed    | accepted |
      | shipped   | rejected |
      | delivered | rejected |

  @FR-011
  Scenario: Cancelling a shipped order is refused with an explanation
    Given the order is shipped
    When Ada cancels the order because she changed her mind
    Then the cancellation is rejected because the order has already shipped
    And the order remains shipped

  @FR-012
  Scenario: Cancelling twice changes nothing the second time
    Given the order has been cancelled
    When Ada cancels the order because she changed her mind
    Then the cancellation is accepted
    And the business is notified only once that the order was cancelled

  @FR-013
  Scenario: A cancellation must state a recognised reason
    When Ada cancels the order because "she is bored"
    Then the cancellation is rejected because the reason is not recognised

  @FR-014
  Scenario: Cancellation tells the business why
    When Ada cancels the order because payment failed
    Then the business is notified that the order was cancelled due to payment failure
