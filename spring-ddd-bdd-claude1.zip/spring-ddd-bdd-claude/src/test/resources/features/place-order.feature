Feature: Order placement
  So that customers can commit to a purchase at a price they have seen,
  an order captures its lines and prices at the moment it is placed.

  Background:
    Given a customer "Ada"

  @FR-001 @smoke
  Scenario: Placing an order with a single line
    When Ada places an order for 2 units of "SKU-100" at 12.50 EUR
    Then the order is placed
    And the order total is 25.00 EUR

  @FR-001
  Scenario: An order with no lines is rejected
    When Ada places an order with no lines
    Then the order is rejected because an order must contain at least one line

  @FR-002
  Scenario Outline: Line quantities must be positive
    When Ada places an order for <quantity> units of "SKU-100" at 12.50 EUR
    Then the placement is <outcome>

    Examples:
      | quantity | outcome  |
      | 1        | accepted |
      | 5        | accepted |
      | 0        | rejected |
      | -1       | rejected |

  @FR-004
  Scenario: An order mixing currencies is rejected
    Given Ada has a basket containing 1 unit of "SKU-100" at 12.50 EUR
    And the basket also contains 1 unit of "SKU-200" at 9.99 USD
    When Ada places the order
    Then the order is rejected because all lines must share one currency

  @FR-005
  Scenario: The total is the sum of the line subtotals
    Given Ada has a basket containing 3 units of "SKU-100" at 10.00 EUR
    And the basket also contains 2 units of "SKU-200" at 4.50 EUR
    When Ada places the order
    Then the order total is 39.00 EUR

  @FR-006
  Scenario: Placement announces the order to the rest of the business
    When Ada places an order for 1 unit of "SKU-100" at 12.50 EUR
    Then the business is notified once that the order was placed
