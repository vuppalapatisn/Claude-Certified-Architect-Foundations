package com.example.orders.ordering.bdd.steps;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.orders.ordering.application.command.CancelOrderCommand;
import com.example.orders.ordering.application.command.CancelOrderUseCase;
import com.example.orders.ordering.bdd.ScenarioContext;
import com.example.orders.ordering.domain.model.OrderStatus;
import com.example.orders.ordering.domain.port.OrderRepository;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.Map;

public class CancelOrderSteps {

  private static final Map<String, String> REASONS =
      Map.of(
          "she changed her mind", "CUSTOMER_CHANGED_MIND",
          "payment failed", "PAYMENT_FAILED",
          "stock ran out", "STOCK_UNAVAILABLE");

  private final CancelOrderUseCase cancelOrder;
  private final OrderRepository orders;
  private final ScenarioContext context;

  public CancelOrderSteps(
      CancelOrderUseCase cancelOrder, OrderRepository orders, ScenarioContext context) {
    this.cancelOrder = cancelOrder;
    this.orders = orders;
    this.context = context;
  }

  @When("{word} cancels the order because {}")
  public void cancelsTheOrderBecause(String customer, String phrase) {
    String reason = REASONS.getOrDefault(phrase.replace("\"", ""), "UNRECOGNISED");
    try {
      cancelOrder.cancel(new CancelOrderCommand(context.orderId().toString(), reason));
      context.failure(null);
    } catch (Exception e) {
      context.failure(e);
    }
  }

  @Then("the cancellation is accepted")
  public void theCancellationIsAccepted() {
    assertThat(context.succeeded()).isTrue();
    assertThat(orders.findById(context.orderId()).orElseThrow().status())
        .isEqualTo(OrderStatus.CANCELLED);
  }

  @Then("the cancellation is rejected")
  public void theCancellationIsRejected() {
    assertThat(context.succeeded()).isFalse();
  }

  @Then("the cancellation is rejected because {}")
  public void theCancellationIsRejectedBecause(String because) {
    assertThat(context.succeeded()).isFalse();
  }

  @Then("the order remains {word}")
  public void theOrderRemains(String state) {
    assertThat(orders.findById(context.orderId()).orElseThrow().status())
        .isEqualTo(OrderStatus.valueOf(state.toUpperCase()));
  }
}
