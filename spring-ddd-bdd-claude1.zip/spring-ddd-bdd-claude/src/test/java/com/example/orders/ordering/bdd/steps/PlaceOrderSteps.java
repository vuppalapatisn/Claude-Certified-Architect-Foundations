package com.example.orders.ordering.bdd.steps;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.orders.ordering.application.command.PlaceOrderCommand;
import com.example.orders.ordering.application.command.PlaceOrderUseCase;
import com.example.orders.ordering.bdd.ScenarioContext;
import com.example.orders.ordering.domain.model.Money;
import com.example.orders.ordering.domain.model.OrderLine;
import com.example.orders.ordering.domain.model.Quantity;
import com.example.orders.ordering.domain.model.Sku;
import com.example.orders.ordering.domain.port.OrderRepository;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.List;
import java.util.UUID;

/**
 * Thin glue: translate one sentence into one call, then assert. No business logic,
 * no conditionals beyond mapping, no new rules.
 */
public class PlaceOrderSteps {

  private final PlaceOrderUseCase placeOrder;
  private final OrderRepository orders;
  private final ScenarioContext context;
  private String customerId;

  public PlaceOrderSteps(
      PlaceOrderUseCase placeOrder, OrderRepository orders, ScenarioContext context) {
    this.placeOrder = placeOrder;
    this.orders = orders;
    this.context = context;
  }

  @Given("a customer {string}")
  public void aCustomer(String name) {
    this.customerId = UUID.randomUUID().toString();
  }

  @Given("{word} has a basket containing {int} unit(s) of {string} at {double} {word}")
  public void aBasketContaining(
      String customer, int quantity, String sku, double price, String currency) {
    context.basket().add(line(sku, quantity, price, currency));
  }

  @Given("the basket also contains {int} unit(s) of {string} at {double} {word}")
  public void theBasketAlsoContains(int quantity, String sku, double price, String currency) {
    context.basket().add(line(sku, quantity, price, currency));
  }

  @When("{word} places an order for {int} unit(s) of {string} at {double} {word}")
  public void placesAnOrderFor(
      String customer, int quantity, String sku, double price, String currency) {
    attemptPlacement(List.of(new PlaceOrderCommand.Line(sku, quantity, format(price), currency)));
  }

  @When("{word} places an order with no lines")
  public void placesAnEmptyOrder(String customer) {
    attemptPlacement(List.of());
  }

  @When("{word} places the order")
  public void placesTheBasket(String customer) {
    attemptPlacement(
        context.basket().stream()
            .map(
                l ->
                    new PlaceOrderCommand.Line(
                        l.sku().value(),
                        l.quantity().value(),
                        l.unitPrice().amount().toPlainString(),
                        l.unitPrice().currency().getCurrencyCode()))
            .toList());
  }

  @Then("the order is placed")
  public void theOrderIsPlaced() {
    assertThat(context.succeeded()).as("placement succeeded").isTrue();
    assertThat(orders.findById(context.orderId())).isPresent();
  }

  @Then("the order total is {double} {word}")
  public void theOrderTotalIs(double expected, String currency) {
    assertThat(orders.findById(context.orderId()).orElseThrow().total())
        .isEqualTo(Money.of(format(expected), currency));
  }

  @Then("the placement is accepted")
  public void thePlacementIsAccepted() {
    assertThat(context.succeeded()).isTrue();
  }

  @Then("the placement is rejected")
  public void thePlacementIsRejected() {
    assertThat(context.succeeded()).isFalse();
  }

  @Then("the order is rejected because {}")
  public void theOrderIsRejectedBecause(String because) {
    assertThat(context.succeeded()).isFalse();
    assertThat(context.failure()).isNotNull();
  }

  private void attemptPlacement(List<PlaceOrderCommand.Line> lines) {
    try {
      context.orderId(placeOrder.place(new PlaceOrderCommand(customerId, lines, null)));
    } catch (Exception e) {
      context.failure(e);
    }
  }

  private static OrderLine line(String sku, int quantity, double price, String currency) {
    return new OrderLine(
        new Sku(sku), new Quantity(quantity), Money.of(format(price), currency));
  }

  private static String format(double value) {
    return String.format("%.2f", value);
  }
}
