package com.example.orders.ordering.domain;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.example.orders.ordering.domain.event.OrderCancelled;
import com.example.orders.ordering.domain.event.OrderPlaced;
import com.example.orders.ordering.domain.model.CancellationReason;
import com.example.orders.ordering.domain.model.CustomerId;
import com.example.orders.ordering.domain.model.Money;
import com.example.orders.ordering.domain.model.Order;
import com.example.orders.ordering.domain.model.OrderId;
import com.example.orders.ordering.domain.model.OrderLine;
import com.example.orders.ordering.domain.model.OrderStatus;
import com.example.orders.ordering.domain.model.Quantity;
import com.example.orders.ordering.domain.model.Sku;
import com.example.orders.shared.error.DomainRuleViolation;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;

/** One test per invariant, including the rejection case. No Spring context. */
class OrderTest {

  private static final Instant NOW = Instant.parse("2026-03-01T10:00:00Z");
  private static final CustomerId ADA = new CustomerId(UUID.randomUUID());

  private static OrderLine line(String sku, int qty, String price) {
    return new OrderLine(new Sku(sku), new Quantity(qty), Money.of(price, "EUR"));
  }

  @Test
  void placingAnOrderRecordsThatItWasPlaced() {
    Order order = Order.place(OrderId.generate(), ADA, List.of(line("SKU-100", 2, "12.50")), NOW);

    assertThat(order.status()).isEqualTo(OrderStatus.PLACED);
    assertThat(order.pullEvents()).singleElement().isInstanceOf(OrderPlaced.class);
  }

  @Test
  void anOrderWithoutLinesIsRejected() {
    assertThatThrownBy(() -> Order.place(OrderId.generate(), ADA, List.of(), NOW))
        .isInstanceOf(DomainRuleViolation.class)
        .hasMessageContaining("at least one line");
  }

  @Test
  void aNonPositiveQuantityIsRejected() {
    assertThatThrownBy(() -> line("SKU-100", 0, "12.50"))
        .isInstanceOf(DomainRuleViolation.class)
        .hasMessageContaining("positive");
  }

  @Test
  void theTotalIsTheSumOfTheLineSubtotals() {
    Order order =
        Order.place(
            OrderId.generate(),
            ADA,
            List.of(line("SKU-100", 3, "10.00"), line("SKU-200", 2, "4.50")),
            NOW);

    assertThat(order.total()).isEqualTo(Money.of("39.00", "EUR"));
  }

  @Test
  void mixingCurrenciesInOneOrderIsRejected() {
    OrderLine euro = line("SKU-100", 1, "12.50");
    OrderLine dollar =
        new OrderLine(new Sku("SKU-200"), new Quantity(1), Money.of("9.99", "USD"));

    assertThatThrownBy(() -> Order.place(OrderId.generate(), ADA, List.of(euro, dollar), NOW))
        .isInstanceOf(DomainRuleViolation.class);
  }

  @Test
  void aPlacedOrderCanBeCancelled() {
    Order order = placedOrder();
    order.pullEvents();

    order.cancel(CancellationReason.CUSTOMER_CHANGED_MIND, NOW);

    assertThat(order.status()).isEqualTo(OrderStatus.CANCELLED);
    assertThat(order.pullEvents()).singleElement().isInstanceOf(OrderCancelled.class);
  }

  @Test
  void aShippedOrderCannotBeCancelled() {
    Order shipped =
        Order.rehydrate(
            OrderId.generate(), ADA, List.of(line("SKU-100", 1, "10.00")), OrderStatus.SHIPPED);

    assertThatThrownBy(() -> shipped.cancel(CancellationReason.CUSTOMER_CHANGED_MIND, NOW))
        .isInstanceOf(DomainRuleViolation.class);

    assertThat(shipped.status()).isEqualTo(OrderStatus.SHIPPED);
  }

  @Test
  void cancellingAnAlreadyCancelledOrderChangesNothing() {
    Order cancelled =
        Order.rehydrate(
            OrderId.generate(), ADA, List.of(line("SKU-100", 1, "10.00")), OrderStatus.CANCELLED);

    cancelled.cancel(CancellationReason.CUSTOMER_CHANGED_MIND, NOW);

    assertThat(cancelled.status()).isEqualTo(OrderStatus.CANCELLED);
    assertThat(cancelled.pullEvents()).isEmpty();
  }

  @Test
  void theLinesCollectionCannotBeMutatedFromOutside() {
    Order order = placedOrder();

    assertThatThrownBy(() -> order.lines().add(line("SKU-999", 1, "1.00")))
        .isInstanceOf(UnsupportedOperationException.class);
  }

  private static Order placedOrder() {
    return Order.place(OrderId.generate(), ADA, List.of(line("SKU-100", 2, "12.50")), NOW);
  }
}
