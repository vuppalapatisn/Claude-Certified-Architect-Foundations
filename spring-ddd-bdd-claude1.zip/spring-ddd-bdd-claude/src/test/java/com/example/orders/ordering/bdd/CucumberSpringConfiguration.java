package com.example.orders.ordering.bdd;

import com.example.orders.OrdersApplication;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/** Boots the real application once for the acceptance suite. */
@CucumberContextConfiguration
@SpringBootTest(classes = OrdersApplication.class)
@ActiveProfiles("local")
public class CucumberSpringConfiguration {}
