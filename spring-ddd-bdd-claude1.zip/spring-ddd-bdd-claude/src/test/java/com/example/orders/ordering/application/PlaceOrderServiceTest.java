package com.example.orders.ordering.application;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.verify;

import com.example.orders.ordering.application.command.PlaceOrderCommand;
import com.example.orders.ordering.application.service.PlaceOrderService;
import com.example.orders.ordering.domain.model.Order;
import com.example.orders.ordering.domain.model.OrderId;
import com.example.orders.ordering.domain.port.DomainEventPublisher;
import com.example.orders.ordering.domain.port.OrderRepository;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** Ports are mocked. No Spring context, no database. */
@ExtendWith(MockitoExtension.class)
class PlaceOrderServiceTest {

  private static final Clock FIXED =
      Clock.fixed(Instant.parse("2026-03-01T10:00:00Z"), ZoneOffset.UTC);

  @Mock private OrderRepository orders;
  @Mock private DomainEventPublisher publisher;
  @Captor private ArgumentCaptor<Order> saved;

  @Test
  void placingAnOrderSavesItAndPublishesTheEvent() {
    PlaceOrderService service = new PlaceOrderService(orders, publisher, FIXED);

    OrderId id =
        service.place(
            new PlaceOrderCommand(
                UUID.randomUUID().toString(),
                List.of(new PlaceOrderCommand.Line("SKU-100", 2, "12.50", "EUR")),
                "key-1"));

    verify(orders).save(saved.capture());
    assertThat(saved.getValue().id()).isEqualTo(id);
    verify(publisher).publish(anyList());
  }
}
