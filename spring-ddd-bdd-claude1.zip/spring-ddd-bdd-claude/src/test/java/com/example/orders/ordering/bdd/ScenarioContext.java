package com.example.orders.ordering.bdd;

import com.example.orders.ordering.domain.model.OrderId;
import com.example.orders.ordering.domain.model.OrderLine;
import io.cucumber.spring.ScenarioScope;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;

/** Scenario-scoped shared state. Never static fields. */
@Component
@ScenarioScope
public class ScenarioContext {

  private final List<OrderLine> basket = new ArrayList<>();
  private OrderId orderId;
  private Exception failure;

  public List<OrderLine> basket() {
    return basket;
  }

  public void orderId(OrderId id) {
    this.orderId = id;
  }

  public OrderId orderId() {
    return orderId;
  }

  public void failure(Exception e) {
    this.failure = e;
  }

  public Exception failure() {
    return failure;
  }

  public boolean succeeded() {
    return failure == null;
  }
}
