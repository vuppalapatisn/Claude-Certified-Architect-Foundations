package com.example.orders;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

/**
 * Enforces ADR-0002 and .claude/rules/00-architecture.md. If one of these fails, the
 * design is wrong, not the test.
 */
@AnalyzeClasses(
    packages = "com.example.orders",
    importOptions = ImportOption.DoNotIncludeTests.class)
class ArchitectureTest {

  @ArchTest
  static final ArchRule domainDependsOnNothingElse =
      noClasses()
          .that()
          .resideInAPackage("..ordering.domain..")
          .should()
          .dependOnClassesThat()
          .resideInAnyPackage("..application..", "..infrastructure..", "..api..");

  @ArchTest
  static final ArchRule domainIsFrameworkFree =
      noClasses()
          .that()
          .resideInAPackage("..ordering.domain..")
          .should()
          .dependOnClassesThat()
          .resideInAnyPackage(
              "org.springframework..",
              "jakarta.persistence..",
              "javax.persistence..",
              "com.fasterxml.jackson..",
              "lombok..");

  @ArchTest
  static final ArchRule applicationDoesNotDependOnAdapters =
      noClasses()
          .that()
          .resideInAPackage("..ordering.application..")
          .should()
          .dependOnClassesThat()
          .resideInAnyPackage("..infrastructure..", "..api..");

  @ArchTest
  static final ArchRule nothingDependsOnTheApi =
      noClasses()
          .that()
          .resideOutsideOfPackage("..ordering.api..")
          .should()
          .dependOnClassesThat()
          .resideInAPackage("..ordering.api..");

  @ArchTest
  static final ArchRule controllersAreNotTransactional =
      noClasses()
          .that()
          .resideInAPackage("..ordering.api..")
          .should()
          .beAnnotatedWith("org.springframework.transaction.annotation.Transactional");
}
