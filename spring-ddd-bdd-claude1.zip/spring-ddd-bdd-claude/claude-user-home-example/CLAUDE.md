# Personal instructions (all projects)

## Who I am
Backend engineer, mainly Java and Kotlin on the JVM. Comfortable with Spring,
JPA, Kafka. Less confident in frontend and infrastructure-as-code — explain
more in those areas, less in mine.

## How I want you to work
- Show a plan before writing code for anything touching more than three files.
- Smallest change that solves the problem. Don't refactor adjacent code unasked.
- When there's a tradeoff, state both options and pick one with a reason.
  Don't present a menu and wait.
- Tell me when I'm wrong. If my premise is mistaken, say so before answering.
- No summary of what you just did if I can see the diff.

## Code style preferences (all languages)
- Explicit over clever. A longer name over a comment explaining a short one.
- Guard clauses over nested conditionals.
- No comments restating the code. Comment the *why*, and only when non-obvious.
- Tests named as behaviour, not `test1`.

## Tooling
- I use `jj` alongside git in some repos — check before assuming git commands.
- Never run `git push`, `git rebase`, or anything that rewrites history.
- Prefer `rg` over `grep`, `fd` over `find`.

## Output preferences
- Code blocks with the language tag. No line numbers.
- When quoting a file, show only the changed region plus a few lines of context.
