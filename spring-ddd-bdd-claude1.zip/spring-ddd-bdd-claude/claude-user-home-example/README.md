# User-scope configuration (`~/.claude/`)

These files are **not** part of the repository. They live in your home
directory, apply to every project on your machine, and are never committed
here. This folder is a template — copy it out:

```bash
mkdir -p ~/.claude/rules
cp claude-user-home-example/CLAUDE.md       ~/.claude/CLAUDE.md
cp claude-user-home-example/rules/*.md      ~/.claude/rules/
cp claude-user-home-example/settings.json   ~/.claude/settings.json
```

Load order: user files load **before** project files, so project instructions
take priority. User-level rules in `~/.claude/rules/` apply to every project,
and unlike project rules reached via symlink, they load without an external
import approval prompt.

Keep personal preferences here and team conventions in the repository. If you
find yourself writing a project-specific fact into `~/.claude/CLAUDE.md`, it
belongs in the project's `CLAUDE.md` or `CLAUDE.local.md` instead.
