# My workflow rules (all projects)

- Run the test suite before telling me something works.
- If a test fails, show me the actual assertion message, not a summary of it.
- Never weaken or disable a test to get a green build. Bring it to me instead.
- When you're uncertain which of two designs I want, ask with a one-line
  summary of each rather than building both.
- If a task turns out to be bigger than it looked, stop and say so early.
