---
paths:
  - "**/*.java"
---

# My Java preferences (any project)

Applies only when I'm working in Java, and only where a project rule doesn't
say otherwise — project rules load after these and take priority.

- Java 21 idioms: records, sealed interfaces, pattern matching in switch,
  text blocks for multi-line strings.
- `var` for obvious local types, explicit types at API boundaries.
- Streams where they clarify; a plain loop where a stream would need a comment.
- `Optional` as a return type only. Never a field, never a parameter.
- Constructor injection. Never `@Autowired` on a field.
- AssertJ over JUnit assertions.
- No `final` on every local variable — noise. Yes on fields.
