# Orders Service — Claude Code project instructions

Spring Boot 3.x / Java 21 service for the **Ordering** bounded context.
Architecture is hexagonal (ports & adapters) with a DDD domain model and BDD acceptance tests.

<!-- Keep this file under ~200 lines. Layer-specific detail belongs in .claude/rules/. -->

## Commands

| Task | Command |
| --- | --- |
| Build + unit tests | `./mvnw verify` |
| Unit tests only | `./mvnw test` |
| BDD/acceptance only | `./mvnw verify -Pbdd` |
| Single test | `./mvnw test -Dtest=OrderTest` |
| Format + import order | `./mvnw spotless:apply` |
| Static analysis | `./mvnw spotless:check checkstyle:check` |
| Architecture tests | `./mvnw test -Dtest=ArchitectureTest` |
| Run locally | `./mvnw spring-boot:run` (profile `local`, H2) |

Run `./mvnw verify` before proposing a commit. Do not commit if it fails.

## Layout

```
src/main/java/com/example/orders/
  ordering/
    domain/          Pure Java. Entities, value objects, domain events, ports.
    application/     Use cases. Orchestrates domain + ports. Transaction boundary.
    infrastructure/  Adapters: JPA, messaging, external clients.
    api/             REST controllers + DTOs.
  shared/            Cross-context primitives and error handling.
docs/requirements/   PRD, functional and non-functional requirements, glossary.
docs/ddd/            Bounded contexts, context map, aggregate and event catalogue.
docs/adr/            Architecture decision records.
src/test/resources/features/  Gherkin feature files.
```

See @docs/ddd/bounded-contexts.md for the context map and
@docs/requirements/glossary-ubiquitous-language.md for the agreed vocabulary.

## Non-negotiable rules

1. **The dependency rule.** `domain` imports nothing from `application`,
   `infrastructure`, or `api`. `application` may import `domain` only.
   Adapters depend inward. `ArchitectureTest` enforces this — if it fails, the
   design is wrong, not the test.
2. **No framework annotations in `domain`.** No `@Entity`, `@Component`,
   `@Autowired`, no Jackson, no JPA. If persistence needs a field, map it in
   `infrastructure/persistence`, not in the aggregate.
3. **Aggregates protect invariants.** No public setters. State changes go
   through intention-revealing methods (`order.cancel(reason)`), which validate
   first and raise a domain event on success.
4. **One aggregate per transaction.** Cross-aggregate consistency is eventual,
   via domain events. Never load two aggregates and mutate both.
5. **Repositories are ports.** Interfaces live in `domain/port`, named for the
   aggregate (`OrderRepository`). JPA implementations live in
   `infrastructure/persistence` with an `Adapter` suffix.
6. **Ubiquitous language.** Class and method names come from the glossary. If
   you need a word that isn't there, add it to the glossary in the same change
   and say so in the PR description.
7. **Behaviour is specified before it is implemented.** New functional
   behaviour starts as a `.feature` scenario. See `.claude/rules/bdd-gherkin.md`.
8. **Migrations are additive and never edited.** Add a new
   `V{n}__{description}.sql`. Never modify an applied migration.

## Conventions

- Java 21. Records for value objects and DTOs. Sealed interfaces for domain events.
- No Lombok in `domain`. Permitted in `infrastructure` and `api` for DTOs only.
- Constructor injection only. No field injection.
- `Optional` for absent return values; never as a parameter or field.
- Money is `Money` (amount + currency). Never `double`, never bare `BigDecimal`.
- IDs are typed value objects (`OrderId`), not `UUID` or `Long`.
- Package-private by default; widen only when a caller outside the package needs it.

## Testing expectations

- Domain logic: plain JUnit 5, no Spring context. Fast.
- Application services: Mockito for ports, no Spring context.
- Adapters: `@DataJpaTest` / `@WebMvcTest` slices, not full `@SpringBootTest`.
- Acceptance: Cucumber against the real application with Testcontainers.
- New behaviour needs a scenario. New branch logic needs a unit test.
  Bug fixes need a failing test first.

## What to ask about rather than assume

- Adding a new bounded context, or a dependency between existing contexts.
- Introducing a new external dependency in `pom.xml`.
- Anything touching `shared/` — it is shared, so changes ripple.
- Changing an existing public REST contract or event payload.

## Working style

Use plan mode for anything touching more than three files. Show the plan
before writing code. Prefer the smallest change that satisfies the scenario.
When a requirement is ambiguous, quote the relevant line from
`docs/requirements/` and ask, rather than inventing behaviour.
