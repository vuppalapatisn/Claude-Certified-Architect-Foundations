## Why

<!-- Requirement or defect ID and one sentence of business context. -->
Requirement: FR-

## What changed

<!-- Grouped by layer, not a file list. -->
- **Domain:**
- **Application:**
- **Adapters (persistence / api / messaging):**
- **Docs:**

## Domain model impact

<!-- New or changed aggregates, invariants, events. "None" is a fine answer. -->

## Contract impact

- [ ] No change to a published REST contract or event schema
- [ ] Additive change only (optional field), consumers unaffected
- [ ] Breaking change — ADR linked, migration plan below

## Migrations

<!-- Each migration, and whether the previous service version still runs against it. -->

## Checklist

- [ ] `./mvnw verify` passes locally
- [ ] Every new functional behaviour has a tagged Gherkin scenario
- [ ] Invariants have unit tests, including the rejection cases
- [ ] `ArchitectureTest` passes — no layer violations
- [ ] No framework annotations added under `domain/`
- [ ] New terms added to `docs/requirements/glossary-ubiquitous-language.md`
- [ ] Requirements doc updated if behaviour changed
- [ ] ADR added for any architectural decision
- [ ] No secrets, no PII in logs or fixtures
- [ ] No `@wip` tags left in feature files

## Assumptions and follow-ups

<!-- Anything inferred rather than confirmed. Be explicit; this is where review value is. -->
