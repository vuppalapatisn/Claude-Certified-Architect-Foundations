---
name: Bug report
about: Behaviour that contradicts a stated requirement
labels: bug, needs-triage
---

## Which requirement is violated?

<!-- FR- or NFR- id from docs/requirements/. If none covers it, this may be a
     feature request or a missing requirement — say so. -->

## Expected, as a scenario

```gherkin
Scenario:
  Given
  When
  Then
```

## Actual

## Reproduction

- Order state:
- Request:
- `OrderId` / trace id:
- Environment and version:

## Impact

<!-- Orders affected, customer-visible or not, workaround available. -->
