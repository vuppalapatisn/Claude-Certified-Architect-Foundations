---
name: Feature request
about: Propose new behaviour for the Orders service
labels: enhancement, needs-triage
---

## Business outcome

<!-- What becomes possible, and for whom. Not the solution. -->

## Behaviour, in the project's language

<!-- Use terms from docs/requirements/glossary-ubiquitous-language.md.
     Draft it as a scenario if you can. -->

```gherkin
Scenario:
  Given
  When
  Then
```

## Rules and edge cases

- Boundary values:
- Rejection paths:
- Idempotency — what happens on a repeat?

## Which context owns this?

<!-- Check docs/ddd/bounded-contexts.md. If it needs a rule owned by Pricing,
     Billing, or Fulfilment, it probably belongs in that service. -->

## New vocabulary

<!-- Terms not yet in the glossary. -->
