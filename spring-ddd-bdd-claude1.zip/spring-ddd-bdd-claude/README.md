# Orders Service

Reference Spring Boot service demonstrating a DDD domain model, hexagonal
layering, BDD acceptance tests, and a full Claude Code configuration.

## Quick start

```bash
./mvnw verify           # build + unit tests
./mvnw verify -Pbdd     # acceptance tests (needs Docker)
./mvnw spring-boot:run  # http://localhost:8080
```

## Claude Code setup

Everything Claude needs is committed. After cloning:

```bash
cp CLAUDE.local.md.example CLAUDE.local.md              # personal notes
cp .claude/settings.local.json.example .claude/settings.local.json
claude                                                   # then run /context
```

`/context` should list `CLAUDE.md`, `CLAUDE.local.md`, and the unconditional
files under `.claude/rules/` in **Memory files**. If a file is missing there,
Claude cannot see it.

| File | Scope | Committed |
| --- | --- | --- |
| `CLAUDE.md` | project, everyone | yes |
| `CLAUDE.local.md` | you, this project | no |
| `~/.claude/CLAUDE.md` | you, all projects | n/a (your home dir) |
| `.claude/rules/*.md` | project, path-scoped | yes |
| `.claude/settings.json` | project permissions + hooks | yes |
| `.claude/settings.local.json` | your overrides | no |
| `.mcp.json` | project MCP servers | yes |

See `docs/CLAUDE-SETUP.md` for what each piece does and why.

## Documentation

- `docs/requirements/` — PRD, functional + non-functional requirements, glossary
- `docs/ddd/` — bounded contexts, context map, aggregates, domain events
- `docs/bdd/` — Gherkin conventions and the living documentation approach
- `docs/adr/` — architecture decision records

## Full structure

```
spring-ddd-bdd-claude/
├── .claude/
│   ├── agents/
│   │   ├── bdd-author.md
│   │   ├── code-reviewer.md
│   │   ├── domain-modeler.md
│   │   ├── security-auditor.md
│   │   └── test-runner.md
│   ├── commands/
│   │   ├── new-aggregate.md
│   │   ├── new-feature-bdd.md
│   │   ├── new-use-case.md
│   │   ├── pr.md
│   │   └── review-architecture.md
│   ├── hooks/
│   │   ├── format-java.sh
│   │   └── guard-domain-purity.sh
│   ├── rules/
│   │   ├── 00-architecture.md
│   │   ├── application-layer.md
│   │   ├── bdd-gherkin.md
│   │   ├── build-and-deps.md
│   │   ├── domain-layer.md
│   │   ├── infrastructure-persistence.md
│   │   ├── rest-api.md
│   │   ├── security.md
│   │   └── testing.md
│   ├── skills/
│   │   ├── bdd-scenario/
│   │   │   └── SKILL.md
│   │   └── ddd-aggregate/
│   │       ├── SKILL.md
│   │       └── reference-aggregate.md
│   ├── settings.json
│   └── settings.local.json.example
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   ├── workflows/
│   │   ├── ci.yml
│   │   └── claude-code-review.yml
│   ├── CODEOWNERS
│   └── pull_request_template.md
├── claude-user-home-example/
│   ├── rules/
│   │   ├── personal-java.md
│   │   └── workflow.md
│   ├── CLAUDE.md
│   ├── README.md
│   └── settings.json
├── docs/
│   ├── adr/
│   │   ├── 0001-record-architecture-decisions.md
│   │   ├── 0002-hexagonal-layering.md
│   │   ├── 0003-bdd-as-acceptance-criteria.md
│   │   └── template.md
│   ├── bdd/
│   │   └── bdd-conventions.md
│   ├── ddd/
│   │   ├── aggregates.md
│   │   ├── bounded-contexts.md
│   │   ├── context-map.md
│   │   └── domain-events.md
│   ├── requirements/
│   │   ├── PRD.md
│   │   ├── functional-requirements.md
│   │   ├── glossary-ubiquitous-language.md
│   │   └── non-functional-requirements.md
│   └── CLAUDE-SETUP.md
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── example/
│   │   │           └── orders/
│   │   │               ├── ordering/
│   │   │               │   ├── api/
│   │   │               │   │   ├── dto/
│   │   │               │   │   │   ├── OrderResponse.java
│   │   │               │   │   │   └── PlaceOrderRequest.java
│   │   │               │   │   └── OrderController.java
│   │   │               │   ├── application/
│   │   │               │   │   ├── command/
│   │   │               │   │   │   ├── CancelOrderCommand.java
│   │   │               │   │   │   ├── CancelOrderUseCase.java
│   │   │               │   │   │   ├── PlaceOrderCommand.java
│   │   │               │   │   │   └── PlaceOrderUseCase.java
│   │   │               │   │   └── service/
│   │   │               │   │       ├── CancelOrderService.java
│   │   │               │   │       └── PlaceOrderService.java
│   │   │               │   ├── domain/
│   │   │               │   │   ├── event/
│   │   │               │   │   │   ├── DomainEvent.java
│   │   │               │   │   │   ├── OrderCancelled.java
│   │   │               │   │   │   └── OrderPlaced.java
│   │   │               │   │   ├── model/
│   │   │               │   │   │   ├── CancellationReason.java
│   │   │               │   │   │   ├── CustomerId.java
│   │   │               │   │   │   ├── Money.java
│   │   │               │   │   │   ├── Order.java
│   │   │               │   │   │   ├── OrderId.java
│   │   │               │   │   │   ├── OrderLine.java
│   │   │               │   │   │   ├── OrderStatus.java
│   │   │               │   │   │   ├── Quantity.java
│   │   │               │   │   │   └── Sku.java
│   │   │               │   │   └── port/
│   │   │               │   │       ├── DomainEventPublisher.java
│   │   │               │   │       └── OrderRepository.java
│   │   │               │   └── infrastructure/
│   │   │               │       └── persistence/
│   │   │               │           ├── OrderJpaEntity.java
│   │   │               │           ├── OrderMapper.java
│   │   │               │           ├── OrderRepositoryAdapter.java
│   │   │               │           └── SpringDataOrderRepository.java
│   │   │               ├── shared/
│   │   │               │   ├── error/
│   │   │               │   │   ├── ApiExceptionHandler.java
│   │   │               │   │   ├── DomainRuleViolation.java
│   │   │               │   │   └── OrderNotFound.java
│   │   │               │   └── ClockConfiguration.java
│   │   │               └── OrdersApplication.java
│   │   └── resources/
│   │       ├── db/
│   │       │   └── migration/
│   │       │       └── V1__create_orders.sql
│   │       └── application.yml
│   └── test/
│       ├── java/
│       │   └── com/
│       │       └── example/
│       │           └── orders/
│       │               ├── ordering/
│       │               │   ├── application/
│       │               │   │   └── PlaceOrderServiceTest.java
│       │               │   ├── bdd/
│       │               │   │   ├── steps/
│       │               │   │   │   ├── CancelOrderSteps.java
│       │               │   │   │   └── PlaceOrderSteps.java
│       │               │   │   ├── CucumberRunnerTest.java
│       │               │   │   ├── CucumberSpringConfiguration.java
│       │               │   │   └── ScenarioContext.java
│       │               │   └── domain/
│       │               │       └── OrderTest.java
│       │               └── ArchitectureTest.java
│       └── resources/
│           └── features/
│               ├── cancel-order.feature
│               └── place-order.feature
├── .gitignore
├── .mcp.json
├── CLAUDE.local.md.example
├── CLAUDE.md
├── README.md
└── pom.xml
```
