# BDD in this project

## The loop

```
Requirement (docs/requirements) ──> Scenario (.feature, tagged @FR-nnn)
        ^                                      │
        │                                      v
   Living documentation  <──  Passing build  <── Domain model + adapters
```

Specification comes before implementation. A scenario that has to be changed to
make the build pass means the requirement was misunderstood — go back to the
requirement, not the test.

## Three amigos before writing

A scenario is drafted with three perspectives present, even informally:
business (what outcome), development (what is feasible), testing (how it fails).
The `bdd-author` subagent stands in for the testing perspective by hunting the
edge cases the requirement omits, but it does not replace the business voice.

## Layout

```
src/test/resources/features/
├── place-order.feature
├── cancel-order.feature
└── view-order.feature

src/test/java/com/example/orders/ordering/bdd/
├── CucumberRunnerTest.java     JUnit Platform suite
├── ScenarioContext.java        scenario-scoped shared state
└── steps/
    ├── PlaceOrderSteps.java
    └── CancelOrderSteps.java
```

## Running

```bash
./mvnw verify -Pbdd                                       # all scenarios
./mvnw verify -Pbdd -Dcucumber.filter.tags="@FR-011"      # one requirement
./mvnw verify -Pbdd -Dcucumber.filter.tags="@smoke"        # smoke set
./mvnw verify -Pbdd -Dcucumber.filter.tags="not @wip"      # exclude in-progress
```

Reports land in `target/cucumber-reports/`. That HTML report is the living
documentation — if it disagrees with `docs/requirements/`, the requirements doc
is stale and must be corrected.

## Tags

| Tag | Meaning |
| --- | --- |
| `@FR-nnn` | Traces to a functional requirement. Mandatory. |
| `@smoke` | Runs on every push. Keep this set small and fast. |
| `@regression` | Full suite, runs on PR and nightly. |
| `@wip` | Excluded from CI. Must not survive a merge. |

## Anti-patterns rejected in review

- A scenario per method or per endpoint rather than per behaviour
- UI or HTTP mechanics in the Gherkin
- Scenarios that depend on execution order, or on data another scenario created
- Assertions inside `Given`
- `Scenario Outline` used to merge behaviours that are actually different rules
- Step definitions containing business logic, conditionals, or loops
