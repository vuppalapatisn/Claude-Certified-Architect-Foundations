# Bounded contexts

## This service

**Ordering** — owns the order lifecycle from placement to hand-off. Sole writer
of order state. Publishes `OrderPlaced` and `OrderCancelled`.

## Neighbours

| Context | Owns | Relationship to Ordering |
| --- | --- | --- |
| **Pricing** | Prices, promotions, tax rules | Ordering is a **customer**; Pricing is upstream. Ordering reads a price and captures it. |
| **Billing** | Payment authorization and capture | Downstream **event subscriber** of `OrderPlaced` / `OrderCancelled`. |
| **Fulfilment** | Picking, packing, shipping | Downstream subscriber; publishes shipment events Ordering observes. |
| **Catalogue** | Products, SKUs, descriptions | Upstream, **shared published SKU** as an identifier only. |
| **Identity** | Customers, accounts, authorization | Upstream; Ordering holds `CustomerId` only. |

## What Ordering deliberately does not own

- Price calculation. Ordering captures a price, never computes one.
- Stock levels. Placement does not reserve stock; Fulfilment handles shortfall.
- Payment state. An unpaid order is still a valid placed order.
- Customer contact details. Ordering stores an ID, nothing more.

The strongest signal that a change is in the wrong service: it requires Ordering
to learn a rule owned by one of the contexts above.
