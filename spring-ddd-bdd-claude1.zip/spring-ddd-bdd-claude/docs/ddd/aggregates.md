# Aggregate catalogue

## Order

**Root:** `Order` · **Identity:** `OrderId` (UUIDv7)

**Contained:** `OrderLine` (entity, reachable only through the root),
`Money`, `Quantity`, `Sku`, `CancellationReason` (value objects)

**Invariants held transactionally:**
1. At least one line (FR-001)
2. Every line quantity is a positive integer (FR-002)
3. All lines share one currency (FR-004)
4. Total equals the sum of line subtotals (FR-005)
5. Status transitions follow the permitted graph only (FR-010, FR-011)
6. Line prices are immutable after placement (FR-003)

**Deliberately eventually consistent:**
- Payment state — Billing's concern, arrives by event
- Stock availability — not checked at placement by design
- Shipment progress — observed from Fulfilment events

**Status graph:**

```
PLACED ──> PICKED ──> PACKED ──> SHIPPED ──> DELIVERED
   │          │          │
   └──────────┴──────────┴──> CANCELLED    (terminal)
```

Cancellation is permitted from `PLACED`, `PICKED`, `PACKED`; rejected from
`SHIPPED` and `DELIVERED`; idempotent from `CANCELLED`.

**Why this boundary:** the six invariants above all concern a single customer's
single order and must hold at commit. Nothing outside the order is needed to
check them, so nothing outside it belongs in the boundary. Stock was considered
and excluded: including it would make every placement contend on a per-SKU row
for a rule the business is willing to resolve after the fact.

## Candidate aggregates (not yet built)

| Candidate | Boundary would hold | Status |
| --- | --- | --- |
| `Return` | Return authorization and its lines | Deferred, needs its own PRD |
| `CancellationPolicy` | The rule set by channel and region | Currently hardcoded; extract when a second policy appears |
