# Context map

```
        ┌────────────┐         ┌────────────┐
        │  Identity  │         │  Catalogue │
        └─────┬──────┘         └──────┬─────┘
              │ CustomerId            │ SKU
              │ (shared identifier)   │ (published identifier)
              v                       v
┌─────────┐        ┌─────────────────────────┐
│ Pricing │──────> │        ORDERING         │
└─────────┘  price │  (this service)         │
   upstream        └───────┬──────────┬──────┘
   customer/supplier       │          │
                OrderPlaced│          │OrderCancelled
                           v          v
                  ┌────────────┐  ┌────────────┐
                  │  Billing   │  │ Fulfilment │
                  └────────────┘  └─────┬──────┘
                                        │ OrderShipped
                                        └──────────> back to ORDERING
```

## Integration patterns

| Pair | Pattern | Notes |
| --- | --- | --- |
| Pricing → Ordering | Customer/Supplier, synchronous | Ordering rejects placement if Pricing is unavailable. It never guesses a price. |
| Ordering → Billing | Published language, async events | Avro on Kafka, schema-registry governed, backward compatible. |
| Ordering → Fulfilment | Published language, async events | Fulfilment translates `Order` into its own pick-list model. |
| Fulfilment → Ordering | Async events, anti-corruption layer | Fulfilment's shipment vocabulary is translated at the adapter; its terms never enter our domain. |
| Identity → Ordering | Shared identifier only | No customer data replicated. |

## Anti-corruption layer

Inbound events from Fulfilment are translated in
`infrastructure/messaging/FulfilmentEventTranslator`. Fulfilment's notion of
"order" — a pick list with bin locations — must not leak into our aggregate.
If a field from their payload appears in `domain`, the ACL has failed.

## Contract change rules

- Adding an optional field to a published event: safe, no coordination.
- Removing or renaming a field, or changing its meaning: new schema version,
  both versions published during transition, ADR required.
- Never break a consumer to make a producer simpler.
