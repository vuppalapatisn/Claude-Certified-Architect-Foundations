# Domain event catalogue

All events are immutable records, named for a business fact in the past tense,
and members of the sealed `DomainEvent` interface. They carry IDs and
primitives, never aggregate references.

## Published by Ordering

### OrderPlaced

| Field | Type | Notes |
| --- | --- | --- |
| `orderId` | `OrderId` | |
| `customerId` | `CustomerId` | |
| `total` | `Money` | amount + currency |
| `lines` | `List<PlacedLine>` | sku, quantity, unit price |
| `placedAt` | `Instant` | when the business fact occurred |

Consumers: Billing (authorize payment), Fulfilment (create pick list),
Analytics. Emitted exactly once per placement (FR-006); duplicate placements
with the same idempotency key emit nothing (FR-007).

### OrderCancelled

| Field | Type | Notes |
| --- | --- | --- |
| `orderId` | `OrderId` | |
| `reason` | `CancellationReason` | from the permitted set (FR-013) |
| `cancelledAt` | `Instant` | |

Consumers: Billing (release authorization), Fulfilment (halt picking).

## Consumed by Ordering

| Event | Source | Effect |
| --- | --- | --- |
| `OrderShipped` | Fulfilment | Status → `SHIPPED`; cancellation window closes |
| `OrderDelivered` | Fulfilment | Status → `DELIVERED` |
| `PaymentFailed` | Billing | Cancels with reason `PAYMENT_FAILED` |

Inbound payloads are translated in the anti-corruption layer. The foreign
vocabulary stops at the adapter.

## Rules

- Recorded by the aggregate, drained and published by the application service
  **after** the transaction commits — via the outbox, so a committed fact is
  never lost and an uncommitted one is never published (NFR-004).
- Consumers must be idempotent; delivery is at-least-once.
- An event describes what happened, never what should happen next. If it reads
  like a command (`CancelOrder`), it is not a domain event.
