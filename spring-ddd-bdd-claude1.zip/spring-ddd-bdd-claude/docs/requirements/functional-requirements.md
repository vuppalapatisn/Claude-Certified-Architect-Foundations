# Functional requirements

Each requirement has an ID used as a Gherkin tag, so scenarios trace back here.
A requirement is not done until a tagged scenario passes.

## Order placement

| ID | Requirement | Scenario |
| --- | --- | --- |
| FR-001 | An order must contain at least one line | `place-order.feature` |
| FR-002 | Every line must have a positive integer quantity | `place-order.feature` |
| FR-003 | A line's unit price is captured at placement and does not change afterwards | `place-order.feature` |
| FR-004 | All lines in an order share one currency; a mixed-currency order is rejected | `place-order.feature` |
| FR-005 | An order total is the sum of its line subtotals | `place-order.feature` |
| FR-006 | Placement emits `OrderPlaced` exactly once | `place-order.feature` |
| FR-007 | A duplicate placement with the same idempotency key returns the original order and emits no second event | `place-order.feature` |

## Order cancellation

| ID | Requirement | Scenario |
| --- | --- | --- |
| FR-010 | A placed, picked, or packed order may be cancelled | `cancel-order.feature` |
| FR-011 | A shipped or delivered order cannot be cancelled | `cancel-order.feature` |
| FR-012 | Cancelling an already-cancelled order succeeds and changes nothing | `cancel-order.feature` |
| FR-013 | Cancellation requires a reason from the permitted set | `cancel-order.feature` |
| FR-014 | Cancellation emits `OrderCancelled` carrying the reason | `cancel-order.feature` |

## Order query

| ID | Requirement | Scenario |
| --- | --- | --- |
| FR-020 | An order can be retrieved by its ID with lines, status, and total | `view-order.feature` |
| FR-021 | Requesting an unknown order returns not-found, not an empty order | `view-order.feature` |
| FR-022 | A customer may only retrieve their own orders | `view-order.feature` |

## Traceability

Every `.feature` scenario carries its `FR-` tag. To run one requirement:

```bash
./mvnw verify -Pbdd -Dcucumber.filter.tags="@FR-011"
```

A requirement with no tagged scenario is not implemented, whatever the code says.
