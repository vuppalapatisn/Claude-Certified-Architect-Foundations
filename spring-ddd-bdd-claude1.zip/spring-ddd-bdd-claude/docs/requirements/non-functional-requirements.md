# Non-functional requirements

| ID | Category | Requirement | How it is verified |
| --- | --- | --- | --- |
| NFR-001 | Latency | p99 place-order < 400 ms, p99 read < 100 ms, measured at the service boundary | k6 load profile in CI nightly |
| NFR-002 | Throughput | 300 orders/sec sustained, 900/sec for 5 minutes | load test |
| NFR-003 | Availability | 99.9% monthly for reads, 99.5% for writes | SLO dashboard, error budget |
| NFR-004 | Durability | No acknowledged order may be lost; event emission is at-least-once with an idempotent consumer contract | transactional outbox + integration test |
| NFR-005 | Consistency | Within an order: strong. Across contexts: eventual, < 5 s p99 | event-lag alert |
| NFR-006 | Security | No PII at rest beyond `CustomerId`; TLS in transit; authorization enforced in the application layer | security review + `security-auditor` |
| NFR-007 | Auditability | Every state transition is reconstructible from the event stream for 7 years | event retention policy |
| NFR-008 | Observability | Every request traced; `OrderId` on every log line; domain events counted per type | trace sampling check |
| NFR-009 | Deployability | Zero-downtime rolling deploy; migrations backward compatible with the previous version | two-version migration test in CI |
| NFR-010 | Recoverability | RPO 1 minute, RTO 15 minutes | quarterly restore drill |
| NFR-011 | Maintainability | Architecture tests enforce layering; build fails on violation | `ArchitectureTest` in `verify` |
| NFR-012 | Portability | Runs on JDK 21; no vendor-specific SQL outside migrations | build matrix |

## Explicit non-goals

- Multi-region active-active. Single region, documented in ADR-0004.
- Sub-100 ms writes. Durability is preferred over write latency.
- Backward compatibility with the monolith's order API. The old endpoint stays
  until decommissioned; the new contract is not constrained by it.
