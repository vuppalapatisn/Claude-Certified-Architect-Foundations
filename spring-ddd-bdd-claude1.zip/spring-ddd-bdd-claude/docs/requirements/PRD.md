# PRD — Orders Service

## Problem

Customers abandon purchases when they cannot see or change an order after
placing it, and support absorbs the resulting contact volume. The current
monolith couples ordering to fulfilment, so any change to cancellation rules
requires a fulfilment release.

## Goal

Own the lifecycle of a customer order from placement to hand-off to fulfilment,
as an independently deployable service with an explicit contract.

## In scope

- Place an order against a priced basket
- Query an order and its lines
- Cancel an order before it ships
- Emit domain events for downstream fulfilment, billing, and analytics

## Out of scope

- Pricing and promotions (Pricing context, consumed via published price)
- Payment capture (Billing context, reacts to `OrderPlaced`)
- Picking, packing, shipping (Fulfilment context)
- Returns and refunds after delivery (later phase, needs its own PRD)

## Success measures

| Measure | Baseline | Target |
| --- | --- | --- |
| Self-service cancellation rate | 0% | 80% of cancellation requests |
| Order-related support contacts | 1,400/wk | < 500/wk |
| p99 place-order latency | n/a | < 400 ms |
| Cancellation-rule change lead time | 3 weeks | < 1 day |

## Constraints

- Must emit events on the existing Kafka cluster, Avro, schema-registry governed
- PII minimisation: the service stores a `CustomerId`, never customer contact details
- Must tolerate Pricing being unavailable by rejecting placement, never by guessing a price

## Open questions

- Partial cancellation of individual lines: in or out for phase 1?
- Does a cancellation after picking but before shipping incur a restocking fee?
- Retention period for cancelled orders?
