# Ubiquitous language

The agreed vocabulary of the Ordering context. Code uses these words exactly.
If you need a word that is not here, add it in the same change and say so in
the PR.

| Term | Means | Does not mean | In code |
| --- | --- | --- | --- |
| **Order** | A customer's committed intent to purchase, priced and immutable in its lines | A basket; a shipment; an invoice | `Order` (aggregate root) |
| **Order Line** | One product at one quantity at the price captured when the order was placed | A shipment line; a stock movement | `OrderLine` (entity within `Order`) |
| **Basket** | A mutable pre-order collection. Lives in another context; never enters this one | An unplaced order | — (out of context) |
| **Place** | To convert a priced basket into an order, fixing prices | To save; to submit; to create | `Order.place(...)` |
| **Cancel** | To end an order before it ships, by customer or operator decision | To refund; to return; to delete | `Order.cancel(reason)` |
| **Cancellation Reason** | One of a fixed set: `CUSTOMER_CHANGED_MIND`, `PAYMENT_FAILED`, `FRAUD_SUSPECTED`, `STOCK_UNAVAILABLE` | Free text | `CancellationReason` (enum) |
| **Ship** | Fulfilment's act of handing goods to a carrier. Ordering only observes it | Deliver; dispatch from the warehouse floor | `OrderStatus.SHIPPED` |
| **Total** | Sum of line subtotals in the order's single currency, excluding shipping and tax | Amount charged; invoice total | `Order.total()` |
| **Money** | An amount paired with a currency | A `double`; a bare `BigDecimal` | `Money` (value object) |
| **Customer** | The party that placed the order, referenced by ID only | A user account; a payer | `CustomerId` (value object) |

## Terms deliberately avoided

- **Manager**, **Helper**, **Processor**, **Handler**, **Data**, **Info** — say
  what the thing actually does.
- **Status change** — name the business event instead (`cancel`, not `setStatus`).
- **Delete an order** — orders are never deleted; they are cancelled.

## Same word, different context

**Order** in Fulfilment means a pick list with a warehouse location. It is a
different concept with the same name, and the two must not share a model. The
translation happens in the event contract, described in `docs/ddd/context-map.md`.
