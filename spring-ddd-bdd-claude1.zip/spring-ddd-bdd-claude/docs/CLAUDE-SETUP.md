# How the Claude configuration fits together

## Load order, broadest to most specific

Claude Code concatenates instruction files rather than overriding them, ordered
from the filesystem root down to your working directory, so instructions closer
to where you launched are read last.

| # | File | Scope | Committed |
| - | --- | --- | --- |
| 1 | managed `CLAUDE.md` (`/etc/claude-code/CLAUDE.md`, `/Library/Application Support/ClaudeCode/CLAUDE.md`, `C:\Program Files\ClaudeCode\CLAUDE.md`) | whole org, cannot be excluded | by IT |
| 2 | `~/.claude/CLAUDE.md` | you, every project | no |
| 3 | `~/.claude/rules/*.md` | you, every project | no |
| 4 | `./CLAUDE.md` | this project, everyone | yes |
| 5 | `.claude/rules/*.md` without `paths` | this project, everyone | yes |
| 6 | `./CLAUDE.local.md` | you, this project | no |
| — | `.claude/rules/*.md` with `paths` | loaded when Claude reads a matching file | yes |
| — | `SKILL.md` files | loaded on demand when relevant | yes |

Verify with `/context` — loaded files appear under **Memory files**. `/memory`
lists and opens them.

## Which mechanism for which job

| Need | Use | Why |
| --- | --- | --- |
| Facts true in every session | `CLAUDE.md` | always in context, costs tokens every turn |
| Rules for one layer or file type | `.claude/rules/` with `paths` | loads only when Claude touches matching files |
| A multi-step procedure | a skill | loads on demand, keeps context clean |
| A workflow you invoke by name | `.claude/commands/` | `/new-use-case OrderCancellation` |
| A focused task in its own context | `.claude/agents/` | isolated window, cheaper model, narrow tools |
| A rule that must hold regardless | a hook | shell command at a lifecycle event, not guidance |
| Blocking a tool or path outright | `permissions.deny` | enforced by the client |

The distinction that matters most: **`CLAUDE.md` is context, not enforcement.**
Claude reads it and tries to comply, but there is no guarantee — especially for
vague or conflicting instructions. Anything that must hold every time belongs in
a `PreToolUse` hook or a `permissions.deny` entry.

## Keeping CLAUDE.md small

Target under 200 lines. Longer files consume more context and reduce adherence.
Imports with `@path` help organisation but do **not** reduce context — imported
files are expanded at launch. To actually save context, move the content into a
path-scoped rule or a skill.

This project keeps `CLAUDE.md` to commands, layout, the eight non-negotiable
rules, and conventions. Every layer detail lives in `.claude/rules/`.

## When to add to CLAUDE.md

Add an instruction when Claude makes the same mistake twice, when a review
catches something Claude should have known, when you retype a correction you
gave last session, or when a new teammate would need the same context.

## Settings precedence

Highest to lowest: managed policy, command-line arguments,
`.claude/settings.local.json`, `.claude/settings.json`, `~/.claude/settings.json`.
Note this is the opposite direction from the instruction files above — local
settings override shared ones, while local instructions are appended after them.

## Auto memory

Separate from `CLAUDE.md`: Claude writes it itself, per repository, into
`~/.claude/projects/<project>/memory/`. It holds your preferences, corrections
you have given, and project context Claude cannot derive from the code — the
index is loaded every session, capped at the first 200 lines or 25KB. It is
machine-local and never committed. Audit it with `/memory`; disable per project
with `"autoMemoryEnabled": false`.

Do not rely on it for team conventions. Those go in the committed files.
