# ADR-0001: Record architecture decisions

- **Status:** accepted
- **Date:** 2026-01-15

## Context

Decisions about layering, aggregate boundaries, and integration patterns were
being made in chat and rediscovered months later by archaeology. New joiners —
and Claude Code — had no way to learn why the codebase is shaped as it is, so
both tended to propose changes that had already been rejected for good reasons.

## Decision

We keep architecture decision records in `docs/adr/`, numbered sequentially,
using `template.md`. An ADR is required for: a new bounded context, a new
integration pattern between contexts, a new infrastructure dependency, a
breaking contract change, and any deliberate departure from the rules in
`.claude/rules/`.

`CLAUDE.md` points at this directory so the reasoning is discoverable in-session.

## Consequences

Decisions gain a small amount of ceremony. In exchange, "why is it like this"
has an answer, and a rejected option stays rejected without being re-argued.
ADRs are immutable once accepted — a changed mind means a new ADR superseding
the old one, not an edit.
