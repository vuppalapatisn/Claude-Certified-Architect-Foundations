# ADR-0003: Gherkin scenarios are the acceptance criteria

- **Status:** accepted
- **Date:** 2026-02-03

## Context

Acceptance criteria lived in ticket descriptions and went stale immediately
after merge. Nobody could answer "what does this service actually guarantee"
without reading the code, and the answer was often different from the ticket.

## Options considered

### Option A — Keep criteria in tickets, test with JUnit only
No new tooling. But criteria and tests drift, and the business cannot read
either one.

### Option B — Gherkin scenarios as the executable acceptance criteria
Requires Cucumber, disciplined step reuse, and a real commitment to declarative
phrasing — imperative Gherkin is worse than no Gherkin.

## Decision

Option B. Every functional requirement in
`docs/requirements/functional-requirements.md` carries an `FR-` id, and every id
has at least one tagged scenario. The Cucumber HTML report is the living
documentation. A requirement with no passing scenario is not implemented.

## Consequences

A slower path from idea to code, because the scenario has to be agreed first.
In exchange the guarantees of the service are readable by non-developers and
verified on every build. The risk is Gherkin drifting into imperative UI-level
steps, which is why `.claude/rules/bdd-gherkin.md` and the `bdd-author` subagent
exist, and why imperative phrasing is a blocking review comment.
