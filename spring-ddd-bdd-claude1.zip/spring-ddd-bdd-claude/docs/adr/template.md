# ADR-NNNN: <short decision title>

- **Status:** proposed | accepted | superseded by ADR-NNNN
- **Date:** YYYY-MM-DD
- **Deciders:** names

## Context

The forces at play: the requirement, the constraint, what makes this a decision
rather than an obvious choice. State facts, not the conclusion.

## Options considered

### Option A — <name>
Description. Consequences, good and bad.

### Option B — <name>
Description. Consequences, good and bad.

## Decision

We chose <option> because <the reason that actually decided it>.

## Consequences

What becomes easier. What becomes harder. What we have committed to living with.
What would cause us to revisit this.
