# ADR-0002: Hexagonal layering with a framework-free domain

- **Status:** accepted
- **Date:** 2026-01-20

## Context

The monolith this service replaces has JPA entities as its domain model. The
consequences are well understood by the team: business rules scattered across
services because entities cannot hold behaviour safely, tests that need a
database to assert a pricing rule, and a model shaped by the schema rather than
by the business.

We need the cancellation rules to be changeable in a day (PRD success measure),
which requires them to be testable in milliseconds and readable in one place.

## Options considered

### Option A — JPA entities as the domain model
Familiar, less code, no mapping layer. But persistence concerns dictate the
model, lazy-loading surprises leak into business logic, and every domain test
needs a Spring context.

### Option B — Separate domain model, mapped to JPA entities in the adapter
A mapping layer to write and maintain. In exchange the domain is plain Java:
instant tests, no framework coupling, boundaries enforceable by a tool.

### Option C — Event sourcing
Full audit trail, which NFR-007 wants. But a substantial step in complexity for
a team with no event-sourcing experience, and the outbox plus event stream
satisfies the audit requirement at far lower cost.

## Decision

Option B. `domain` is plain Java with no framework imports, enforced by
`ArchitectureTest` and by the `guard-domain-purity` PreToolUse hook rather than
by review discipline alone.

## Consequences

We write and maintain mappers between aggregates and JPA entities — accepted
cost. Domain tests need no Spring context and run in milliseconds. The model can
be reshaped without a migration, and the schema can change without touching the
model. Two representations of the same concept exist, so a new field must be
added in both; the architecture test catches the case where someone shortcuts it.
